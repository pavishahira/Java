function mult(){
    var n1;
    var n2;
    var p;
    
    n1=parseInt(document.getElementById("n1").value);
    n2=parseInt(document.getElementById("n2").value);
    
    p=n1*n2;
    //document.write(n1+"x"+n2+"="+p);
    var retans;
    retans=n1+"x"+n2+"="+p;   //7x8=56
    document.getElementById("ans").innerHTML=retans;
    }
    
