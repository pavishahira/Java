function myfunc(){
    document.write("java script");
    alert("hello");
}