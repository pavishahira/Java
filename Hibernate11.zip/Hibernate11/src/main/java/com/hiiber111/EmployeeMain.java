package com.hiiber111;


import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeMain {
	public static void main(String[] args) {
	        Configuration config =new Configuration();
	        config .configure("hibernate1.cfg.xml");
	        config.addAnnotatedClass(Employee.class);
		SessionFactory sf=config.buildSessionFactory();
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();
		Employee eob=new Employee();
		
	    eob.setEid(11);
		eob.setEname("riya");
		eob.setEsalary(567890);
		eob.setEmailid("riya@gmail.com");
		ss.save(eob);
		t.commit();
		System.out.println("record is saved successfully");
	}

}

