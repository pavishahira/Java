package com.springhello;

public class HelloSpring1 {

	public void display() {
		System.out.println("hai,how are you?");
		
	}

}
