package com.Constructor;

class Addition1{
	int i,j,s;
	Addition1(){
		this(8);
		System.out.println("No arg constructor");
		}
	Addition1(int i){
		System.out.println("One arg constructor");
		}
	void add(int i,int j) {
		this.i=i;
		this.j=j;
		System.out.println("inside addition"+this);
		s=i+j;
	}
	void display() {
		System.out.println("sum of"+i+"and" +j+ "is=" +s);
	}
}
public class Demo1 {

	public static void main(String[] args) {
	Addition1 ob=new Addition1();
	Addition1 ob1=new Addition1();
	System.out.println("Created object"+ob);
	ob.add(3, 4);
	ob.display();
	ob1.add(7, 4);
	ob1.display();
	}
	}
