package com.Constructor;
class ClassConstructor{
	int i,j,k;
	ClassConstructor(){
		System.out.println("Constructor with no arg");
	}
	ClassConstructor(int i){
		System.out.println("Constructor with one arg"+i);
	}
	ClassConstructor(int i,int j){
		System.out.println("Constructor with two arg"+i+"and"+j);
	}
	ClassConstructor(int i,int j,int k){
		System.out.println("Constructor with three arg"+i+","+j+ "and" +k);
	}
}

public class ConstructorOverload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ClassConstructor ob1=new ClassConstructor();
ClassConstructor ob2=new ClassConstructor(3);
ClassConstructor ob3=new ClassConstructor(3,5);
ClassConstructor ob4=new ClassConstructor(3,2,5);
	}

}
