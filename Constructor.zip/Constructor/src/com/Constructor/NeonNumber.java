package com.Constructor;
import java.util.Scanner;

public class NeonNumber {

	public static void main(String[] args) {
		int sum=0,a;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number to check:");
		a=sc.nextInt();
		int square=a*a;
		while(square!=0) {
			int digit=square%10;
			sum=sum+digit;
			square=square/10;
		}
    if(a==sum) {
			System.out.println("neon number"+a);
		}
			else {
				System.out.println("is not a neon number"+a);
			}
		
		}

}


