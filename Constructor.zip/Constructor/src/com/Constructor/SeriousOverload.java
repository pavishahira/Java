package com.Constructor;

public class SeriousOverload {
	void series(int x,int n) {
		float sum=0;
		for(int i=1;i<=n;i++) {
			sum=(float)(sum+Math.pow(x, i));
		}
		System.out.println("sum of the given series="+sum);
	}
void series(int p) {
	int t=0;
	for(int i=1;i<=p;i++) {
		t=(i*i*i)-1;
		System.out.println(t+" , ");
	}
	System.out.println();
}
void series() {
	float sum=0;
	for(int i=2;i<=9;i++) {
		sum=sum+(float)1/i;	}
System.out.println("sum of the given series="+sum);
}
	public static void main(String[] args) {
SeriousOverload ob=new SeriousOverload();
ob.series();
ob.series(12);
ob.series(2,12);
	}

}
