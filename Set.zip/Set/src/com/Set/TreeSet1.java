package com.Set;
import java.util.Set;
import java.util.TreeSet;
public class TreeSet1 {

	public static void main(String[] args) {
		Set<Integer>ob=new TreeSet<Integer>();
		ob.add(78);
		ob.add(34);
		ob.add(8);
		ob.add(55);
		System.out.println(ob);
	}

}
