package com.Set;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;
class Studentt{
	int id;
	String name;
	float fees;
	public
	Studentt(int id,String name,float fees) {
		super();
		this.id=id;
		this.name=name;
		this.fees=fees;
	}
	@Override
	public String toString() {
		return "Studentt [id=" + id + ", name=" + name + ", fees=" + fees + "]";
	}
	}
class SortSid implements Comparator<Studentt>{

	@Override
	public int compare(Studentt o1,Studentt o2) {
		if(o1.id==o2.id) 
		    return 0;
		else if(o1.id<o2.id)
			return -1;
		else
			return 1;
					
	}
	
}

public class TreeSet2 {

	public static void main(String[] args) {
	Studentt s1=new Studentt(1,"pavi",78654.5f);
		Studentt s2=new Studentt(2,"dinesh",7665.4f);
		Studentt s3=new Studentt(3,"anu",7643.2f);
		
		SortSid sob=new SortSid();
		
		Set<Studentt> tob=new TreeSet<Studentt>(sob);
		tob.add(s1);
		tob.add(s2);
		tob.add(s3);
		
		System.out.println(tob);
	}

}


