package com.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
public class Set2{
	public static void main(String[] args) {
		Set<Integer>sob=new HashSet<Integer>(); 
		sob.add(43);
		sob.add(32);
		sob.add(45);
		sob.add(23);
		sob.add(45);
		sob.add(null);
		System.out.println(sob);
		System.out.println("LinkedHashSet");
		Set<Integer>sob1=new LinkedHashSet<Integer>(); 
		sob1.add(43);
		sob1.add(32);
		sob1.add(45);
		sob1.add(23);
		sob1.add(45);
		sob1.add(null);
      System.out.println(sob1);
		System.out.println("TreeSet Elements");
		System.out.println("TreeSet");
		Set<Integer>sob2=new TreeSet<Integer>();                                           
		sob2.add(43);
		sob2.add(32);
		sob2.add(45);
		sob2.add(23);
		sob2.add(45);
		System.out.println(sob2);
	}

}

