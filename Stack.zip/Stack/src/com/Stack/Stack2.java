package com.Stack;
import java.util.*;  
public class Stack2 {  
public static void main(String args[])   
{  
Stack <Integer> stk = new Stack<>();  
System.out.println("stack: " + stk);  

pushelmnt(stk, 33);  
pushelmnt(stk, 43);  
pushelmnt(stk, 23);  
pushelmnt(stk, 45);  
pushelmnt(stk, 11);  
pushelmnt(stk, 46);  
pushelmnt(stk, 54);   
popelmnt(stk);  
popelmnt(stk);  
 try   
{  
popelmnt(stk);  
}   
catch (EmptyStackException e)   
{  
System.out.println("empty stack");  
}  
}   
static void pushelmnt(Stack stk, int x)   
{       
stk.push(new Integer(x));  
System.out.println("push -> " + x);   
System.out.println("stack: " + stk);  
}    
static void popelmnt(Stack stk)   
{  
System.out.print("pop -> ");  
Integer x = (Integer) stk.pop();  
System.out.println(x);  
System.out.println("stack: " + stk);  
}  
}  



