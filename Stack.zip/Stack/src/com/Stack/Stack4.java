package com.Stack;

import java.util.Stack;  
public class Stack4{
public static void main (String[] args)   
{     
Stack <Integer> stk = new Stack<>();  
stk.push(221);  
stk.push(343);  
stk.push(564);  
System.out.println("Iteration over the stack using forEach() Method:");    
stk.forEach(n ->  
{  
System.out.println(n);  
});  
}  
}  
