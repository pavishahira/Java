package com.Map;
import java.util.HashMap;
import java.util.Map;

public class HashMap2{
     public static void main(String a[]){
        Map<Integer, String> hashmapp = new HashMap<Integer, String>();
        hashmapp.put(1, "pavi");
        hashmapp.put(2, "dinesh");
        hashmapp.put(3,"abi");
        hashmapp.put(4,"anu");
        hashmapp.put(5,"raji");
        System.out.println(hashmapp);
        System.out.println("Value of second: "+hashmapp.get(2));
        System.out.println("Is HashMap empty? "+hashmapp.isEmpty());
        hashmapp.remove(1);
        System.out.println(hashmapp);
        System.out.println("Size of the HashMap: "+hashmapp.size());
    }
}
