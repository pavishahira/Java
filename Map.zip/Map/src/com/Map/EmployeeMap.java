package com.Map;
import java.util.HashMap;
import java.util.Map;
public class EmployeeMap {

	public static void main(String[] args) {
				Map<Integer,String>mp=new HashMap<Integer, String>();
				mp.put(1, "pavi");
				mp.put(2, "dinesh");
				System.out.println(mp);
				System.out.println("Employee name="+mp.get(1));
				mp.remove(1);
				System.out.println(mp);
				
			}

		}


	