package com.Array;

class Subjects{
	 int science;
	 int social;
	 int maths;
	 }
public class SubWiseStudentMark {
    public static void main(String[] args) {

		Subjects stu=new Subjects();
		stu.science=90;
		stu.social=98;
		stu.maths=100;
		Subjects stu2=new Subjects();
		stu2.science=90;
		stu2.social=100;
		stu2.maths=100;
		System.out.println("Mark of first student");
		System.out.println("science="+stu.science);
		System.out.println("social="+stu.social);
		System.out.println("maths="+stu.maths);
		System.out.println("Mark of second student");
		System.out.println("science="+stu2.science);
		System.out.println("social="+stu2.social);
		System.out.println("maths="+stu2.maths); 

	}

}
