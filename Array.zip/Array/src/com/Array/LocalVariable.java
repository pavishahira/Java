package com.Array;

public class LocalVariable {
		public void StudentAge() {
			int age=0;
			age=age+20;
			System.out.println("student age is="+age);
			}
		public static void main(String[] args) {
			LocalVariable s=new LocalVariable();
			s.StudentAge();
			

	}

}
