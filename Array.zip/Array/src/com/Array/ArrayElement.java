package com.Array;

public class ArrayElement {

	public static void main(String[] args) {
	int ar[]; 
	ar=new int[5];
	System.out.println("Default values of an array");
	for(int i=0;i<ar.length;i++) {
		System.out.println(ar[i]);	
	}
		
	

	}

}
