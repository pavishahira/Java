package com.Array;
import java.util.Scanner;

public class ArrayMaxMin {
  public static void main(String[] args) {
              int ar[]=new int[5];
			   int sum=0, max,min;
			   Scanner sc=new Scanner(System.in);
			   //input the array elemnts
			   System.out.println("Enter the "+ar.length+" elements");
		        for(int i=0;i<ar.length;i++) {
		        	ar[i]=sc.nextInt();
		        }
		        
		        //display
		        System.out.println("Array elements are");
		        for(int i:ar) {
		        	System.out.println(i);
		        }
		        
		        //sumof all array elements
		        for(int i=0;i<ar.length;i++) {
		        	sum=sum+ar[i];
			    }
		//max of array elements 
		        max=ar[0];
		        for(int i=1;i<ar.length;i++) {  //{4,2,6,9,8}  max=4
		        	if(ar[i]>max) { //2>4  6>4  9>6   8>9
		        		max=ar[i];  //max=6 max=9  
		        	}
		        }
		        System.out.println("Maximum elements ="+max);

		         //try minimum element
		        min=ar[0];
		        for(int i=1;i<ar.length;i++) {
		        	if(ar[i]<min) {
		        		min=ar[i];
		        	}
		        }
		        System.out.println("Minimum element is "+min);
		   }
		}

	


