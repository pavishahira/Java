package com.Array;

class student{
	public static double fees;
	public static String name="pavi";
	}

public class StudentFees {

	public static void main(String[] args) {
		int student_fees=20000;
		System.out.println("pavi fees is="+student_fees);
		

	}

}
