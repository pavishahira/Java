package com.Array;

public class OpertorsExperiment {
	public static void main(String[] args) {
		int num1,num2;
		num1=10;
		num2=20;
		int output=num1+num2;
		System.out.println("addition"+output);
		int output1=num1-num2;
		System.out.println("Subtraction"+output);
		int output2=num1*num2;
		System.out.println("multiplication"+output);
		int output3=num1/num2;
		System.out.println("division"+output);
		int output4=num1%num2;
		System.out.println("modulo division"+output);
		double no=10,resultNo;
		boolean flag=true;
		System.out.println("+no"+ +no);
		System.out.println("+no"+ -no);
		System.out.println("+no"+ ++no);
		System.out.println("+no"+ --no);
		System.out.println("!flag="+!flag);
		if(num1>num2) {
			System.out.println("no is greater than no1");
		}
		if(num1==num2) {
			System.out.println("no1 equal to no2");
		}
	
		
		int num3=20;
		boolean result;
		result=(num1>num2)||(num3>num1);
		System.out.println("logical opertor"+result);
		result=(num1>num2)&&(num3>num1);
		System.out.println("logical opertor"+result);
		
		int febdays=29;
		String display;
		display=(febdays==28)?"not a leap year":"leap year";
		System.out.println("year is"+display);
		int a=20;
		int b=10;
		int c=2;
		c=a&b;
		System.out.println("a&b="+c);
		
		c=a|b;
		System.out.println("a|b="+c);
		
		c=a^b;
		System.out.println("a^b="+c);
		
		c=~a;
		System.out.println("~a="+c);
		
		c=a>>2;
		System.out.println("a>>2="+c);
		
		c=a<<2;
		System.out.println("a<<2="+c);
		
		
		}
			
	}

