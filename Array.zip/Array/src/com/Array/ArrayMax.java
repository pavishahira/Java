package com.Array;

import java.util.Scanner;

public class ArrayMax {

	public static void main(String[] args) {
		int ar[]=new int[5];
		int sum=0,max;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the"+ar.length+"elements");
		for(int i=0;i<ar.length;i++) {
		ar[i]=sc.nextInt();
		}
System.out.println("Array elements are");
for(int i:ar) {
	System.out.println(i);	
}
for(int i=0;i<ar.length;i++) {
	sum=sum+ar[i];
}
System.out.println("total=" +sum);
max=ar[0];
for(int i=1;i<ar.length;i++) {
	if(ar[i]>max) {
		max=ar[i];
	}
}
System.out.println("maximum element=" +max);
}
}
