package com.Array;

public class PrimitiveDataType {

	public static void main(String[] args) {
		boolean A=true;
		System.out.println("boolean is"+A);
		byte range;
		range=124;
		System.out.println("range of byte is"+range);
		short range1;
		range1=-127;
		System.out.println("range of short is"+range1);
		int range2=4;
		System.out.println("range of int is"+range2);
		long range3=3342L;
		System.out.println("range of long is"+range3);
		double no=456.453;
		System.out.println(" double is"+no);
		float q=23.5f;
		System.out.println(" double is"+q);
		char line='a';
		System.out.println(" char is"+line);
		String name="pavi";
		System.out.println(" String is"+name);
		char line1=65;
		System.out.println(" char is"+line1);
		char line2='\u0041';
		System.out.println(" char is"+line2);
		}

}
