package com.UserInputData;

import java.util.Scanner;


public class Student {
  public static void main(String[] args) {
	String sname;
	int sage;
	float stotalmark;
	Scanner sc=new Scanner(System.in);
	System.out.println("name:");
	sname=sc.nextLine();
	System.out.println("age:");
	sage=sc.nextInt();
	System.out.println("totalmark:");
	stotalmark=sc.nextFloat();
	System.out.println("name:"+sname);
	System.out.println("name:"+sage);
	System.out.println("name:"+stotalmark);
	}

}
