package com.looping;

public class ReverseNo {

	public static void main(String[] args) {
		int no=1234,reverse=0;
		for(;no!=0;no=no/10)
			
		{
			int remainder=no%10;
			reverse=reverse*10+remainder;
		}
		System.out.println("The reverse of the given no is:"+reverse);		
	}

}
