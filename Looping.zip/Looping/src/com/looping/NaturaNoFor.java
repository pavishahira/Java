package com.looping;

public class NaturaNoFor {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=100;i++) {
			System.out.println(i);
		}

	}

}
