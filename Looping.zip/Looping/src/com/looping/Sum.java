package com.looping;

public class Sum {

	public static void main(String[] args) {
		int i=1,s=0;
		while(i<=10) {
			s=s+i;
			i=i+1;
			{
				System.out.println("sum"+s);
			}
			
		}

	}

}
