package com.looping;

public class DoWhile {

	public static void main(String[] args) {
		int i;
		i=1;
		do {
			System.out.println(i);
			i++;
			}
while(i<=50);
}

}
