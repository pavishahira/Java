package com.looping;

public class Decrement {

	public static void main(String[] args) {
		int i;
		i=7;
		while(i>=1) {
			System.out.println(i);
			i--;
			}
		

	}

}
