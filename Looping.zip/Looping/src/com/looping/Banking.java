package com.looping;

import java.util.Scanner;

class Bank{
	float amount;
	void deposit(float depositamount) {
		amount=amount+depositamount;
		System.out.println("bal in the bank after deposit"+amount);
	}
	void withdraw(float withdraw) {
		if(withdraw>amount) {
			System.out.println("Insuffficient bal!!!!!");
			System.out.println("Available bal="+amount);
		}
			else {
				amount=amount-withdraw;
				System.out.println("after amount withdraw available bal"+amount);
			
		}
	}
}

public class Banking {

	public static void main(String[] args) {
	  float damount,wamount;
	  Bank ob=new Bank();
	  Scanner sc=new Scanner(System.in);
	  while(true) {
		  System.out.println("*****MENU FOR MY BANK*****");
		  System.out.println("1.deposit");
		  System.out.println("2.withdraw");
		  System.out.println("enter ur choice");
		  int choice=sc.nextInt();
		  switch(choice) {
		  case 1:   System.out.println("enter the amount to deposit");
		  damount=sc.nextFloat();
		  ob.deposit(damount);
		  break;
		  case 2:  System.out.println("enter the amount to withdraw");
		  wamount=sc.nextFloat();
		  ob.deposit(wamount);
		  break;
		  default:System.out.println("invaild");
			  }
	  System.out.println("do you want to continue(y/n)");
	  char option=sc.next().charAt(0);
	  if(option=='n') {
		  break;
	  }
	  }
	  System.out.println("exit");

	}

}
