package com.looping;

import java.util.Scanner;
class Area{
	float length,breadth, base,height,radius, area,pi;
	Scanner sc = new Scanner(System.in);
	 void areaSquare() {
		 System.out.println("Enter length of square");
		 length=sc.nextFloat();
		 area=length*length;
		 System.out.println("Area of square ="+area);
	 }
	public void areaReactangle() {
		System.out.println("Enter length and breasth of reactangle");
		 length=sc.nextFloat();
		 breadth=sc.nextFloat();
		 area=length*breadth;
		 System.out.println("Area of Reactangle="+area);
		
	}
	public void areaTriangle() {
		System.out.println("Enter base and height of triangle");
		base=sc.nextFloat();
		height=sc.nextFloat();
		area=(base*height)/2;
		System.out.println("Area of Traingle="+area);
		
	}
	public void areaCircle() {
		pi=3.14159f;
		System.out.println("Enter radius of a Circle");
		radius=sc.nextFloat();
		area=pi*radius*radius;
		System.out.println("Area of circle ="+area);
		
	}
}

public class AreaMain {

	public static void main(String[] args) {
		int choice;
		
		Area aob=new Area();
		Scanner sc = new Scanner(System.in);
		while(true) {
		System.out.println("**********MENU*************");
	   System.out.println("1.Area of Square");
	   System.out.println("2.Area of Reactangle");
	   System.out.println("3.Area of Triangle");
	   System.out.println("4.Area of Circle");
	    System.out.println("Enter your choice");
	    choice=sc.nextInt();
	    
	    switch(choice) {
	    case 1: aob.areaSquare();
	             break;
	    case 2:aob.areaReactangle();
	            break;
	    case 3:aob.areaTriangle();
	           break;
	    case 4:aob.areaCircle();
	           break;
	     default:System.out.println("Invalid input");     
	    
	    }//switch ends
	    
	    System.out.println("Do you want to continue (y/n)");
	    char ch=sc.next().charAt(0);
	    if(ch=='n') {
	    	break; //comes out of the loop(exit the loop)
	    }
		} 
		System.out.println("Terminated program");
	}

}


