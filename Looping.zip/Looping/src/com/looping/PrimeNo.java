package com.looping;
import java.util.Scanner;

public class PrimeNo {

	public static void main(String[] args) {
		int i,num,fc=0;
	       Scanner input= new Scanner(System.in);
	       System.out.println("Enter num");
	       num =input.nextInt();
	       for(i=1;i<=num;i++)
	       {
	            if(num%i==0)
	            {
	                fc++;
	              
	            }
	       }
	         
	        if(fc==2)
	        {
	          System.out.println(num+"is Prime");
	        }  
	        else
	        {
	          System.out.println(num+"is Not Prime");
	        }

		
	}

}
