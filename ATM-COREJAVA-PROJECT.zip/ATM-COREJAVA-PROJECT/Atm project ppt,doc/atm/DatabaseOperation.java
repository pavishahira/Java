package com.atm;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class DatabaseOperation {
    private static Connection con;
    private static Statement ss;
    private static ResultSet rr;
    static int balancrenquiry;
    static int deposit;
    static int withdraw;
    static int pinno;
    static Scanner sc=new Scanner(System.in);
    public static void balRecord() {
		System.out.println("enter pinno:");
		pinno=sc.nextInt();
	try {
		System.out.println("Balance : "+balancrenquiry);  
        System.out.println("");  
	con=DatabaseCon.getConnection();
	ss=con.createStatement(); 
	String swl="select * from atm1 where pinno="+pinno;
	rr=ss.executeQuery(swl);
	if(rr.next()) {
		String ud="update atm1 set balancrenquiry="+balancrenquiry+" where pinno="+pinno;
		int val=ss.executeUpdate(ud);
		if(val>0) {
			
		   System.out.println("balanceenquiry successfully");
			
		}
	else {
		System.out.println(pinno+" not exists");
	}
	}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
  }
	
	public static void depositRecord() {
		System.out.println("enter pinno:");
		pinno=sc.nextInt();
		System.out.println("Enter your deposit");
		deposit=sc.nextInt();
		if(balancrenquiry<=deposit)
		 {
	  balancrenquiry = balancrenquiry + deposit;  
        System.out.println("Your Money has been successfully depsited"); 
		 }
        else {
			 System.out.println("insufficient bal");
		 }
        System.out.println(""); 
		try {
			 
		con=DatabaseCon.getConnection();
		ss=con.createStatement(); 
			String swl="select * from atm1 where pinno="+pinno;
			rr=ss.executeQuery(swl); 
			if(rr.next()) {
				String ud="update atm1 set deposit= "+deposit+" where pinno="+pinno;
				int val=ss.executeUpdate(ud);
				if(val>0) {
					
				   System.out.println("deposit is changed successfully");
					
				}
			else {
				System.out.println(pinno+" not exists");
			}
			
			}}//try
		catch(Exception e) {
			e.getStackTrace();
	}
	}
	public static void withdrawRecord() {
		System.out.println("enter pinno:");
		pinno=sc.nextInt();
		System.out.println("withdraw");
		 withdraw = sc.nextInt();
		 if(balancrenquiry>=withdraw)
		 {
		balancrenquiry = balancrenquiry - withdraw;  
       System.out.println("Please collect your money");  
		 }else {
			 System.out.println("insufficient bal");
		 }
       System.out.println("");  
		try {
			con=DatabaseCon.getConnection();
		ss=con.createStatement(); 
			String swl="select * from atm1 where pinno="+pinno;
			rr=ss.executeQuery(swl); 
			if(rr.next()) {
				String ud="update atm1 set withdraw="+withdraw+" where pinno="+pinno;
				int val=ss.executeUpdate(ud);
				if(val>0) {
					
				   System.out.println("withdraw is changed successfully");
					
				}
			else {
				System.out.println(pinno+" not exists");
			}
			
			}}//try
		catch(Exception e) {
			e.getStackTrace();
	}
	}
	
	
}
				
	
		
	
		


		
	
	

