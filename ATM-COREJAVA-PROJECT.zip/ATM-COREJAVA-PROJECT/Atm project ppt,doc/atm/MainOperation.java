package com.atm;
import java.util.Scanner;

public class MainOperation {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("*********Welcome to ATM*************");
		System.out.println("1.Checck balance");
		System.out.println("2.deposit");
		System.out.println("3.withdraw");
		System.out.println("4.Exit");
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch(ch) {
		case 1:DatabaseOperation.balRecord();
			   break;
		case 2:DatabaseOperation.depositRecord();
			  break;
		case 3:DatabaseOperation.withdrawRecord();
		  break;
		case 4:System.out.println("Program is Terminated");
		        System.exit(0);
			   
		  }
		
		}

	}

}




