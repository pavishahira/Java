package com.sqlpgm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecord {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver"; 	
		String un="root"; 		
		String pass="root"; 	
		String url="jdbc:mysql://localhost:3306/schoolstudent";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student id");
		int id=sc.nextInt();
		System.out.println("enter student name");
		String sn=sc.next();
		try { 			
			Class.forName(driver); 		
			conn=DriverManager.getConnection(url,un,pass); 		
			st=conn.createStatement(); 			
			//check the record with id exists or not 		
			String sql="select * from student where sid="+id; 		
			rs=st.executeQuery(sql); 	
			if(rs.next()) { 			
				System.out.println(id+" already exist"); 		
				} 		
			else { //go for insert record 		
				String ins="insert into student values("+id+",'"+sn+"')"; 	
				System.out.println("insert statement "+ins); 	
				int val=st.executeUpdate(ins); 			
				if(val>0) { 
					System.out.println("Student record inserted");
		}else {
			System.out.println("Record not inserted" );
		}
		} //else for insert record
	
	}catch(Exception e) {
		e.printStackTrace();
	}

}

}
