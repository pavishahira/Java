package com.sqlpgm;
import java.sql.Connection;

import java.sql.DriverManager; 
import java.sql.ResultSet; 
import java.sql.Statement; 
public class MySqlComment {  	
	public static void main(String[] args) { 	
	
		//Connection: connect MYSQL with Java 	
		//1. Load the Dirver 		
		//2. Make a connections 		
		//3. create statement object 		
		//4.Excecute Query (insert , select ,delete 	 	
		String driver="com.mysql.cj.jdbc.Driver"; 	
		String un="root"; 		
		String pass="root"; 	
		String url="jdbc:mysql://localhost:3306/schoolstudent"; 		
				//1. load the driver
		try { 			Class.forName(driver); 	
				Connection conn=DriverManager.getConnection(url,un,pass); 	
				Statement st=conn.createStatement(); 			 
		String sel="select * from student"; 			
		ResultSet rs=st.executeQuery(sel); 		
		System.out.println("Student Information"); 	
		System.out.println("Sid\tSname"); 			 	
		while(rs.next()) { 			
			int id=rs.getInt("sid"); //or rs.getInt(1); 
			String n=rs.getString("sname");//rs.getString(2); 		
			System.out.println(id+"\t"+n); 		
			} 		}catch(Exception e) {
					e.printStackTrace();
				}
		}

		}




