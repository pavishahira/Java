package com.sqlpgm;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecord {

	public static void main(String[] args) {

		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/schoolstudent";
		String un="root";
		String pass="root";
		Connection conn=null; 
		Statement st=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id");
		int id=sc.nextInt();
		try {
			Class.forName(driver); 
			conn=DriverManager.getConnection(url,un,pass); 
			st=conn.createStatement(); 
			String sql="select * from student where sid="+id;
			rs=st.executeQuery(sql); 
			if(rs.next()) {
			String del="delete from student where sid="+id;
			
			int val=st.executeUpdate(del);
			
			if(val>0) {
				System.out.println("Student record deleted");
			}else {
				System.out.println("Record not deleted" );
			}
			}
			else {
				System.out.println(id+" not exists");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
     }
}
