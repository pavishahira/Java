package com.demospring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demospring.entity.Employee;
import com.demospring.repository.EmployeeRepository;

@Service
public class EmployeeServiceImp implements EmployeeService{
@Autowired
private EmployeeRepository employeeRepository;

@Override
public Employee saveEmployee(Employee employee) {
	return employeeRepository.save(employee);	
}
}