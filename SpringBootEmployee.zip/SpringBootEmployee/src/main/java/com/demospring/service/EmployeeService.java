package com.demospring.service;

import com.demospring.entity.Employee;
public interface EmployeeService {

	public Employee saveEmployee(Employee employee);
}