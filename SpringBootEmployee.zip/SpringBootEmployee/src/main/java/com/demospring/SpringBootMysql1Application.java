package com.demospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMysql1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMysql1Application.class, args);
	}

}
