	package com.Variable;

  public class Subtraction {
	public static void main(String args[]) {
		int num1,num2,ans;
		num1=44;
		num2=33;
		ans=num1-num2;
		System.out.println("sum="+ans);
		System.out.println("the sub of  "+num1+" and  "+num2+" is  "+ans);
		
	}

}