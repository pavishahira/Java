package com.Variable;

public class Division {
	public static void main(String args[]) {
		int num1,num2,ans;
		num1=50;
		num2=5;
		ans=num1/num2;
		System.out.println("sum="+ans);
		System.out.println("the div of  "+num1+" and  "+num2+" is  "+ans);
		
	}

}
