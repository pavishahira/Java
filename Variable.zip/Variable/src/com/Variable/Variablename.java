package com.Variable;

public class Variablename {
	public static void main(String args[]) {
		int firstnum=10;
		float secondnum=34.2f;
		double thirdnum=564.345;
		char ch='s';
		String s="pavi";
		System.out.println("1st num="+firstnum);
		System.out.println("2nd num="+secondnum);
		System.out.println("3rd num="+thirdnum);
		System.out.println("1st num="+ch);
		System.out.println("1st num="+s);
		
	}

}
