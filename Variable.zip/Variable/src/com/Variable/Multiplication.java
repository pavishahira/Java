package com.Variable;

public class Multiplication {
	public static void main(String args[]) {
		int num1,num2,ans;
		num1=5;
		num2=2;
		ans=num1*num2;
		System.out.println("sum="+ans);
		System.out.println("the mul of  "+num1+" and  "+num2+" is  "+ans);
		
	}

}
