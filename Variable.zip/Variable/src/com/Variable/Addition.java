package com.Variable;

public class Addition {
	public static void main(String args[]) {
		int num1,num2,ans;
		num1=99;
		num2=97;
		ans=num1+num2;
		System.out.println("sum="+ans);
		System.out.println("the sum of  "+num1+" and  "+num2+" is  "+ans);
		
	}

}
