package com.Duque;
import java.util.ArrayDeque;  
import java.util.Deque;  
  public class Deque3 {  
public static void main(String[] args) {  
   Deque<String> deque = new ArrayDeque<String>();   
   deque.addFirst("Java");  
    System.out.println("The first element is : "+deque);  
    deque.addFirst("Python");  
    System.out.println("After adding the next element in the front of the deque : "+deque);  
     deque.add("Ruby");  
     System.out.println("The final deque is  : "+deque);   
     int size =  deque.size();  
     System.out.println("The number of elements are : "+size);   
     deque.removeLast();  
 System.out.println("Deque after removing the last element is given as :  "+deque);  
   }      
}  


