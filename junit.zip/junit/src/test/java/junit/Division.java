package junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Division {
DivisionClass ob=new DivisionClass(10,2);
DivisionClass ob1=new DivisionClass(10,0);
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	@Test
	public void test1() {
		assertEquals(5,ob.divisionNum());
		
	}
	@Test (expected = ArithmeticException.class)
	
public void test2() {
	assertEquals(5,ob1.divisionNum());
}
}
