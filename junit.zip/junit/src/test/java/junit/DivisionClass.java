package junit;

public class DivisionClass {
int a1,a2;
public  DivisionClass(int a1,int a2) {
	this.a1=a1;
	this.a2=a2;
}
public int divisionNum()throws ArithmeticException{
	return a1/a2;
}
}
