package com.hiiber;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
	        Configuration config =new Configuration();
	        config .configure("hibernate.cfg.xml");
	        config.addAnnotatedClass(Emp11.class);
		SessionFactory sf=config.buildSessionFactory();
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();
		Emp11 eob=new Emp11();
		
	    eob.setId(11);
		eob.setFirstName("Pavithra");
		eob.setLastName("S");
		ss.save(eob);
		t.commit();
		System.out.println("record is saved successfully");
	}

}
