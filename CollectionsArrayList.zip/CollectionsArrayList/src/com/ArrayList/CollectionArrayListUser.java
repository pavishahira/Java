package com.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;

class Student{
	 int sid;
	 String sname;
   float fees;
	public Student(int sid, String sname, float fees) { 
		super(); 
		this.sid = sid;
		this.sname = sname;
		this.fees = fees;
	}
	@Override  
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", fees=" + fees + "]";
	}	
}

public class CollectionArrayListUser {

	public static void main(String[] args) {
		Student s1=new Student(1, "anu", 3456.7f); 
		Student s2=new Student(2, "abi", 3456.6f);
		Student s3=new Student(3,"Dinesh",9876.5f);
		Student s4=new Student(4,"Pavi",8765.2f);
		
		ArrayList<Student> sobj=new ArrayList<Student>();
		sobj.add(s1);
		sobj.add(s2);
		sobj.add(s3);
		sobj.add(s4);
		System.out.println(sobj); 
		Iterator<Student>sitor=sobj.iterator();
		
		System.out.println("ID\tNAME\tFEES"); 
		
		while(sitor.hasNext()) { 
			Student st1=sitor.next();
			System.out.println(st1.sid+"\t"+st1.sname+"\t"+st1.fees);
		}
		
	}

}


