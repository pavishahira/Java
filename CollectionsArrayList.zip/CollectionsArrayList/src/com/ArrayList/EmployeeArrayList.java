package com.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;

class Employee{
	 int eid;
	 String ename;
     int eage;
     String eaddress;
     float esalary;
     
	public Employee(int eid, String ename,int eage ,String eaddress,float esalary) { 
		super(); 
		this.eid = eid;
		this.ename = ename;
		this.eage = eage;
		this.eaddress=eaddress;
		this.esalary=esalary;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eage=" + eage + ", eaddress=" + eaddress + ", esalary="
				+ esalary + "]";
	}
	
}

public class EmployeeArrayList {

	public static void main(String[] args) {
		Employee s1=new Employee(1, "anu", 25,"nagercoil",30000); 
		Employee s2=new Employee(2, "abi", 24,"nagercoil",50000);
		Employee s3=new Employee(3,"Dinesh",26,"banglore",50000);
		Employee s4=new Employee(4,"Pavi",25,"nagercoil",40000);
		
		ArrayList<Employee> sobj=new ArrayList<Employee>();
		sobj.add(s1);
		sobj.add(s2);
		sobj.add(s3);
		sobj.add(s4);
		System.out.println(sobj); 
		Iterator<Employee>sitor=sobj.iterator();
		
		System.out.println("ID\tNAME\tFEES"); 
		
		while(sitor.hasNext()) { 
			Employee e1=sitor.next();
			System.out.println(e1.eid+"\t"+e1.ename+"\t"+e1.eage+"\t"+e1.eaddress+"\t"+e1.esalary);
		}
		
	}

}




