package com.ArrayList;
import java.util.ArrayList;

public class ArrayListt {

	public static void main(String[] args) {
		//Resizable array
		ArrayList lob=new ArrayList();
		lob.add(34);
		lob.add(87.4f);
		lob.add(9.56);
		lob.add("Hello");
		lob.add(true);
		lob.add(6);
		
		System.out.println(lob);
   }
 }

