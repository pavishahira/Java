package com.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

class Employee2{
	int eid;
	String ename;
	int eage;
	float esalary;	
	public Employee2() {
		super();
		
	}

void inputEmployee2() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Details");
		System.out.println("Enter name");
		ename=sc.next();
		System.out.println("Enter Employee id");
		eid=sc.nextInt();
		System.out.println("Enter employee age");
		eage=sc.nextInt();
		System.out.println("Enter Employee salary");
		esalary=sc.nextFloat();
	}
}

public class EmployeeList1 {

	public static void main(String[] args) {
		Employee2 e1=new Employee2();
		Employee2 e2=new Employee2();
		Employee2 e3=new Employee2();
		Employee2 e4=new Employee2();
		
		e1.inputEmployee2();
		e2.inputEmployee2();
		e3.inputEmployee2();
		e4.inputEmployee2();
		
		ArrayList<Employee2>lemp=new ArrayList<Employee2>();//LinkedList or Vector
		lemp.add(e1);
		lemp.add(e2);
		lemp.add(e3);
		lemp.add(e4);
		
		//Display Employee
		Iterator<Employee2> eit=lemp.iterator();
		
		System.out.println("Employee Details");
		System.out.println("___________________________________________________");
		System.out.println("ID\tName\tAge\tSalary");
		while(eit.hasNext()) {
			Employee2 empobj=eit.next();
			System.out.println(empobj.eid+"\t"+empobj.ename+"\t"+empobj.eage+"\t"+empobj.esalary);
		}
	}

}



