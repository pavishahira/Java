package com.ArrayList;

import java.util.ArrayList;

public class ArrayList1{

	public static void main(String[] args) {
		//Resizable array
		ArrayList<Integer> lob=new ArrayList<>();
		lob.add(34);
		lob.add(45);
		lob.add(76);
		lob.add(6);
		
		System.out.println(lob);
		//ArrayList iteration using enhanced for loop
		for(int i:lob) {
			System.out.println(i);
			
		}
		
		//declare one more ArrayList which takes float values
		ArrayList<Float> fob=new ArrayList<Float>();
		fob.add(76.7f);
		fob.add(65.4f);
		fob.add(98.7f);
		
		System.out.println(fob);
		
		//using for loop
		
		for(float i:fob) {
			System.out.println(i);
		}
		
		////declare one more ArrayList which takes String values
		
		
	    ////declare one more ArrayList which takes double values
   }
 }


