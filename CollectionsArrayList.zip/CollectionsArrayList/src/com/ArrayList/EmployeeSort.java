package com.ArrayList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

class Employeee{
	int eid;
	String ename;
	int eage;
	float esalary;
	
public Employeee() {
		super();
		
	}

	void inputEmployeee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Details");
		System.out.println("Enter name");
		ename=sc.next();
		System.out.println("Enter Employee id");
		eid=sc.nextInt();
		System.out.println("Enter employee age");
		eage=sc.nextInt();
		System.out.println("Enter Employee salary");
		esalary=sc.nextFloat();
	}
}

class SortEmpSalary implements Comparator<Employeee>{

	@Override
	public int compare(Employeee e1, Employeee e2) {
		if(e1.esalary==e2.esalary)
		     return 0;
		else if(e1.esalary<e2.esalary)
			return -1;
		else 
			return 1;
					
	}
	
}

public class EmployeeSort{

	public static void main(String[] args) {
		Employeee e1=new Employeee();
		Employeee e2=new Employeee();
		Employeee e3=new Employeee();
		Employeee e4=new Employeee();
		
		e1.inputEmployeee();
		e2.inputEmployeee();
		e3.inputEmployeee();
		e4.inputEmployeee();
		
		ArrayList<Employeee>lemp=new ArrayList<Employeee>();//LinkedList or Vector
		lemp.add(e1);
		lemp.add(e2);
		lemp.add(e3);
		lemp.add(e4);
		
		//Display Employee
		Iterator<Employeee> eit=lemp.iterator();
		
		System.out.println("Employee Details");
		System.out.println("___________________________________________________");
		System.out.println("ID\tName\tAge\tSalary");
		while(eit.hasNext()) {
			Employeee empobj=eit.next();
			System.out.println(empobj.eid+"\t"+empobj.ename+"\t"+empobj.eage+"\t"+empobj.esalary);
		}
		
		//Sort Employee data
		SortEmpSalary esort=new SortEmpSalary();
		Collections.sort(lemp,esort);
		System.out.println("After Sorting Employee Based on Salary");
		//Display Employee
				Iterator<Employeee> eit1=lemp.iterator();
				
				System.out.println("Employee Details");
				System.out.println("___________________________________________________");
				System.out.println("ID\tName\tAge\tSalary");
				while(eit1.hasNext()) {
					Employeee empobj1=eit1.next();
					System.out.println(empobj1.eid+"\t"+empobj1.ename+"\t"+empobj1.eage+"\t"+empobj1.esalary);
				}
				
				//Sort based on age, based on id, and based name
	}
}

