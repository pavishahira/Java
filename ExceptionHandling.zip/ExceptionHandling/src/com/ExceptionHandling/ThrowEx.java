package com.ExceptionHandling;
import java.util.Scanner;

public class ThrowEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b,c=0;
Scanner sc=new Scanner(System.in);
System.out.println("enter the value of a");
a=sc.nextInt();
System.out.println("enter the value of b");
b=sc.nextInt();
try{
if(b==0) {
	throw new ArithmeticException("divide by zero error");
}
}
catch(ArithmeticException e) {
	e.printStackTrace();
}

	}

}
