package com.ExceptionHandling;
 import java.util.Scanner;
public class DivideByZero {

	public static void main(String[] args) {
		float a,b,c=0;
System.out.println("enter a,b:");
Scanner sc=new Scanner(System.in);
a=sc.nextFloat();
b=sc.nextFloat();
try
{
c=a/b;
}
catch(ArithmeticException e) {
	e.printStackTrace();
	System.out.println(e);
	}
finally {
	System.out.println("finally");
}
System.out.println("c="+c);
System.out.println("After division");
	}
	
	
}
