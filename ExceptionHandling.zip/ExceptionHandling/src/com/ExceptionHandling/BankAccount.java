package com.ExceptionHandling;
 class BankBal extends Exception{
	 public BankBal(String s) {
		 super(s);
	 }
 }
class BankAc{
	float amount;
	public BankAc() {
		amount=2000;
	}
	void withdraw(float bamount) {
		try {
			if(bamount>amount) {
				throw new BankBal("Insuficient balance");
			}
			else {
				amount=amount-bamount;
				System.out.println("bank balance="+amount);
			}
		}
		catch(BankBal e){
			e.printStackTrace();
		}
	}
}
public class BankAccount {

	public static void main(String[] args) {
		BankAc ob=new BankAc();
		ob.withdraw(200);
}

}
