package com.ExceptionHandling;

public class MainAppp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c=0;
		System.out.println("Before division");
		try {
			c=a/b;
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
			System.out.println(e);
		}
		System.out.println("c="+c);
		System.out.println("After division");
	}

}
