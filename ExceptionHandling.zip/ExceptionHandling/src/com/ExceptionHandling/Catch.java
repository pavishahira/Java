package com.ExceptionHandling;
public class Catch{

	public static void main(String[] args) {
		int a=10, b=0,c=0;
		int ar[]={5,7,8,1,2};

		try{
		      c=a/b;  //exception
		      ar[7]=34; //exception
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException e){//java 7 onwards
		    e.printStackTrace();
		}
		finally {
			System.out.println("finally block executes always");
		}
	}

}


