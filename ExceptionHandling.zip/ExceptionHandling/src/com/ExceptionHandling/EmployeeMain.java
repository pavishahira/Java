package com.ExceptionHandling;
class EmployeeException extends Exception{
	public EmployeeException(String s) {
		super(s);
	}
}
class Employee{
	public void checkId(int eid) {
		try {
			if(eid<=0 || eid>=999) {
				throw new EmployeeException("Invaild Employee Id");
			}
			else {
				System.out.println("employee id is valid");
			}
		}
			catch(EmployeeException e) {
				e.printStackTrace();	
		}
	}
}
public class EmployeeMain {

	public static void main(String[] args) {
	Employee ob=new Employee();
	ob.checkId(200);

	}

}
