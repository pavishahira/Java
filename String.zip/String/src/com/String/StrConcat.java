package com.String;

public class StrConcat {

	public static void main(String[] args) {
		String s1="gud morng";
		String s2="pavi";
		System.out.println(s1+"  "+s2);
		System.out.println("hello" +4+6);
		System.out.println(6+8+ "hello");
		System.out.println((4+3)+ "hello");
		String s4=s1.concat(s2);
		System.out.println(s4);

	}

}
