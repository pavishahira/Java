package com.String;

public class String2 {

	public static void main(String[] args) {
	StringBuffer str=new StringBuffer("cooking");
	str.append("banking");
	System.out.println(str);
	str.insert(2, "technology");
	System.out.println(str);
	str.replace(8, 16,"IOT");
	str.reverse();
	System.out.println(str);
	
	System.out.println(str.capacity());
	}

}
