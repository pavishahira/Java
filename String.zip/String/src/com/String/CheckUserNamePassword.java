package com.String;

import java.util.Scanner;

public class CheckUserNamePassword {

	public static void main(String[] args) {
		String uname,upass;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		uname=sc.next();
		System.out.println("enter password");
		upass=sc.next();
		if(uname.equalsIgnoreCase("pavi")&&upass.equals("pavi@234")){
			System.out.println("valid user");
		}
		else {		System.out.println("Invalid user");

	}

}
}
