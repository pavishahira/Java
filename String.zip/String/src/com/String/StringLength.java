package com.String;

public class StringLength {

	public static void main(String[] args) {
		String s="pavithra";
		System.out.println("no of char in a string="+s.length());
		System.out.println("part of a string="+s.substring(2));
		System.out.println("part of a string="+s.substring(2,7));

	}

}
