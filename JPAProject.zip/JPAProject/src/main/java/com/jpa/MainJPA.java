package com.jpa;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainJPA {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
	EntityManager em=emf.createEntityManager();
	StudentsJpa s;
	s=em.find(StudentsJpa.class, 1);
	System.out.println(s);
	em.getTransaction().begin();
	StudentsJpa ob=new StudentsJpa();
	ob.setId(1);
	ob.setName("arthi");
	ob.setFees(9000f);
	em.persist(ob);
	em.getTransaction().commit();
	System.out.println("record is saved");
	StudentsJpa ob1;
	s=em.find(StudentsJpa.class,3);
	System.out.println(s);
}
}

