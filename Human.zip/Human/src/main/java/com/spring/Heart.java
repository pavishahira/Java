package com.spring;

public class Heart {
	public Heart() {
		System.out.println("Heart Constructor");
	}
	public void heartBeating() {
		System.out.println("Heart is functioning");
	}

}
