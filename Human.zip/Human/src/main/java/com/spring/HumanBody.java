package com.spring;

public class HumanBody {
	Heart heart;
	
	public HumanBody() {
		super();
		System.out.println("constructor with no arg");
	}
	public HumanBody(Heart heart) {
		this.heart=heart;
	}
	public void heartBeat() {
		if(heart!=null) {
			heart.heartBeating();
		}
		else {
			System.out.println("Heart is not beating");
		}
	}

}
