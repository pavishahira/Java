package com.opertors;

public class Comparasion {

	public static void main(String[] args) {
int i=6,j=2;
boolean b;
b=i>j;
System.out.println("b="+b);
	}

}
