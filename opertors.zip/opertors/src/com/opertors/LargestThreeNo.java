package com.opertors;
import java.util.Scanner;

public class LargestThreeNo {

	public static void main(String[] args) {
		int fnum,snum,tnum,lar;
		Scanner sc=new Scanner(System.in);
		System.out.println("3 no's:");
		fnum=sc.nextInt();
		snum=sc.nextInt();
		tnum=sc.nextInt();
		lar=(fnum>snum && fnum>tnum)?fnum:(snum>fnum && snum>tnum)?snum:tnum;
		System.out.println("the lar of"  +fnum+ " ," +snum+ "and" +tnum+ "is" +lar);

	}

}
