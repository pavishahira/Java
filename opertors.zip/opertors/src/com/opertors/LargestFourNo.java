package com.opertors;

import java.util.Scanner;

public class LargestFourNo {

	public static void main(String[] args) {
		int fnum,snum,tnum,cnum,lar;
		Scanner sc=new Scanner(System.in);
		System.out.println("4 no's:");
		fnum=sc.nextInt();
		snum=sc.nextInt();
		tnum=sc.nextInt();
		cnum=sc.nextInt();
		lar=(fnum>snum && fnum>tnum && fnum>cnum)?fnum:(snum>fnum && snum>tnum && snum>cnum)?snum:(tnum>fnum && tnum>snum && tnum>cnum)?tnum:fnum;
		System.out.println("the lar of"  +fnum+ "," +tnum+ " ," +snum+ "and" +cnum+ "is" +lar);

	}

}
