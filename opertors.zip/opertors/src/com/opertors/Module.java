package com.opertors;

public class Module {

	public static void main(String[] args) {
		int i=5,j=3,q,r;
		r=i%j;
		System.out.println("r="+r);
		q=i/j;
		System.out.println("q="+q);

	}

}
