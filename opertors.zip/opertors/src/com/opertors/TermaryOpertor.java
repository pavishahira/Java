package com.opertors;

import java.util.Scanner;

public class TermaryOpertor {

	public static void main(String[] args) {
		int fnum,snum,lar;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 2:");
		fnum=sc.nextInt();
		snum=sc.nextInt();
		lar=(fnum>snum)?fnum:snum;
		System.out.println("lar"+fnum+" and "+snum+" is "+lar);

	}

}
