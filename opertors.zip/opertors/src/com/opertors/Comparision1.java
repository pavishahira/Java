package com.opertors;

public class Comparision1 {

	public static void main(String[] args) {
	 int i=8,j=2;
	 boolean b;
	 b=i>j;
	 System.out.println("b="+b);
	 b=i<j;
	 System.out.println("b"+b);
	 b=(i==j);
	 System.out.println("both or equal or not"+b);

	}

}
