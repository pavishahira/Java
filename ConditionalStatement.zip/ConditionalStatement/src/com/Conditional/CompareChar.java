package com.Conditional;

import java.util.Scanner;

public class CompareChar {

	public static void main(String[] args) {
		char ch;
		System.out.println("Char:");
		Scanner sc=new Scanner(System.in);
		ch=sc.next().charAt(0);
		if(ch=='a') {
		System.out.println("vowel");

	}
		else if(ch=='e') {
		System.out.println("vowel");

	}
		else if(ch=='i') {
		System.out.println("vowel");

	}
		else if(ch=='o') {
		System.out.println("vowel");

	}
		else if(ch=='u') {
		System.out.println("vowel");

	}
		else
		{
			System.out.println("consonant");
		}
	}
}

