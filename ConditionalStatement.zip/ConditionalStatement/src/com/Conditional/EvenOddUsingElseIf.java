package com.Conditional;

import java.util.Scanner;

public class EvenOddUsingElseIf {
int num;
void inputNum() {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter no:");
	num=sc.nextInt();
}
 void EvenOdd() {
	if(num%2==0)
	{
		System.out.println("even"+num);
	}
	else
	{
		System.out.println("odd"+num);
	}
	}
	public static void main(String[] args) {
		EvenOddUsingElseIf s=new EvenOddUsingElseIf();
		s.inputNum();
		s.EvenOdd();
			}
		}
		

	