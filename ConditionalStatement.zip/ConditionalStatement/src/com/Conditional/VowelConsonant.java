package com.Conditional;

import java.util.Scanner;

public class VowelConsonant {

	public static void main(String[] args) {
			char ch;
			Scanner sc=new Scanner(System.in);
			System.out.println("Char:");
			ch=sc.next().charAt(0);
			if(ch=='A'||ch=='a') {
			System.out.println("vowel"+ch);

		}
			else if(ch=='E'||ch=='e') {
			System.out.println("vowel"+ch);

		}
			else if(ch=='I'||ch=='i') {
			System.out.println("vowel"+ch);
		

		}
			else if(ch=='A'||ch=='o') {
			System.out.println("vowel"+ch);

		}
			else if(ch=='U'||ch=='u') {
			System.out.println("vowel"+ch);

		}
			else
			{
				System.out.println("consonant");
			}
		}
	}
	}

}
