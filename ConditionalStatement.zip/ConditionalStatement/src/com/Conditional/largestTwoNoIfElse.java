package com.Conditional;

import java.util.Scanner;

public class largestTwoNoIfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int fnum,snum;
Scanner sc=new Scanner(System.in);
System.out.println("2 no's:");
fnum=sc.nextInt();
snum=sc.nextInt();
if(fnum>snum) {
	System.out.println(fnum+"is larger than"+snum);	
}
else
{
	System.out.println(fnum+"is larger than"+snum);	
}
	}

}
