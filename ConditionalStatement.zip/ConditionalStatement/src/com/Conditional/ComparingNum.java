package com.Conditional;

import java.util.Scanner;

 class Num {
		int num;
		void InputData() {
			Scanner sc=new Scanner(System.in);
			System.out.println("num:");
			num=sc.nextInt();
		}
		void checknum() {
			if(num==10)
			{
				System.out.println("10");
			}
			else if(num==20)
			{
				System.out.println("20");
			}
			else if(num==30)
			{
				System.out.println("30");
			}
			else if(num==40)
			{
				System.out.println("40");
			}
			else
			{
				System.out.println("invaild");
			}
		}
			public class ComparingNum{
			public static void main(String[] args) {
				Num s=new Num();
				s.InputData();
				s.checknum();
		}

	}

		}
