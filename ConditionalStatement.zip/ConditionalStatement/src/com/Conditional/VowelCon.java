package com.Conditional;

import java.util.Scanner;

public class VowelCon {

	public static void main(String[] args) {
		char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("Char:");
		ch=sc.next().charAt(0);
		if(ch=='A'||ch=='E'||ch=='I'||ch='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
		{
			System.out.println("vowel"+ch);

			}
				else
				{
					System.out.println("consonant");
			
		}

	}

}
