package com.Conditional;

import java.util.Scanner;

public class EvenOdd {

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		if(num%2==0) {
			System.out.println("even"+num);
		}
			if(num%2==1) {
				System.out.println("odd"+num);	
			
		}
		

	}

	}
