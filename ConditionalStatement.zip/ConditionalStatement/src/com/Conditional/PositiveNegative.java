package com.Conditional;

import java.util.Scanner;

 class positiveneg{
	int num;
		void inputNum() {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter no:");
			num=sc.nextInt();
		}
 

		 void PosNegg() {
			if(num>0)
			{
				System.out.println("pos");
			}
			else
			{
				System.out.println("neg");
			}
		 }
public class PositiveNegative {
			public static void main(String[] args) {
				positiveneg s=new positiveneg();
				s.inputNum();
				s.PosNegg();
					}
				
	}
 }


