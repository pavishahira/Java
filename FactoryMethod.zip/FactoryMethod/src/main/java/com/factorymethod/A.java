package com.factorymethod;
public class A implements Printable{

	public void print() {
		System.out.println("Hello A");
		
	}  
      
}  
