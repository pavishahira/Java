package com.factorymethod;

public class B implements Printable{

	public void print() {
		System.out.println("B class");
		
	}
}
