package com.factorymethod;

	public interface Printable {  
		void print();  
		}  

