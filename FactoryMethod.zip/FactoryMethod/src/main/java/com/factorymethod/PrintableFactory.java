package com.factorymethod;

public class PrintableFactory {
	 public static Printable getPrintable() {
	 //return new A();
	 return new B();
	 }
	 
	}