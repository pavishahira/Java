package com.FunctionOverloading;

class Functionoverload{
	void addition(int i,int j) {
		int s=i+j;
		System.out.println("The addition of two integer numbers is"+s);
		}
	void addition(float i,float j) {
		float s=i+j;
		System.out.println("The addition of two float numbers is"+s);
		}
	void addition(double i,double j) {
		double s=i+j;
		System.out.println("The addition of two double numbers is"+s);
		}
	void addition(short i,short j) {
		short s=(short)(i+j);
		System.out.println("The addition of two short numbers is"+s);
		}
	void addition(byte i,byte j) {
		byte s=(byte)(i+j);
		System.out.println("The addition of two byte numbers is"+s);
		}
	void addition(long i,long j) {
		long s=(long)(i+j);
		System.out.println("The addition of two long numbers is"+s);
		}
}
	
public class Function1 {

	public static void main(String[] args) {
		Functionoverload s=new Functionoverload();
		s.addition(2.3,4.3);
		s.addition(4,3);
		s.addition(3.4f,2.1f);
		s.addition((short)2,(short)4);
		s.addition((byte)3, (byte)4);
		s.addition(345,234);
		
		}

	}


