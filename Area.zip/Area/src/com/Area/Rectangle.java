package com.Area;

public class Rectangle {
	public static void main(String args[]) {
	int l,b,a;
	b=4;
	l=5;
	a=l*b;
	a=5*4;
	System.out.println("area of Rectangle"+a);
	
	}
}


