package com.Area;

public class Square {
	public static void main(String args[]) {
	int s,a;
	s=2;
	a=s*s;
    System.out.println("area of Square"+a);
	
	}
}


