package com.Area;

public class Circle {
	public static void main(String args[]) {
	float p,r,a;
	p=22/7;
	r=10;
    a=p*r*r;
	System.out.println("area of Circle"+a);
	
	}
}

