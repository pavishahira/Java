package com.Area;

public class Triangle {
	public static void main(String args[]) {
	float b,h,a;
	b=12;
	h=24;
	a=1/2*b*h;
	a=12*24/2;
	System.out.println("area of triangle"+a);
	
	}
}
