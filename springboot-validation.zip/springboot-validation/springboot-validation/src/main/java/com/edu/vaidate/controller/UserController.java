package com.edu.vaidate.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.vaidate.entity.User;
import com.edu.vaidate.service.UserService;

@RestController
public class UserController {

	//inject object of UserService
	@Autowired
	private UserService userService;
	@PostMapping("/createUser")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
		User saveUser=userService.createUser(user);
		return new ResponseEntity<User>(saveUser,HttpStatus.CREATED);
	}
}
