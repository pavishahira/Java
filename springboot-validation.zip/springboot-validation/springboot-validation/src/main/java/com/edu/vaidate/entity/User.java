package com.edu.vaidate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;


@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer userId;
	@NotEmpty
	//@Size(min=3, max=30, message="Name should be min 3 chars and max=30 chars")
	private String userName;
	
	@NotEmpty(message="Useremail id should not be blank or not null")
	@Email(message="Invalid Email id")
	
	private String userEmail;
	@NotEmpty(message="Password should not be Empty or not null")
	@Size(min=3, max=30, message="Name should be min 3 chars and max=30 chars")
	private String userPassword;
	@Min(value=18, message="age should be greater than equal to 18 ")
	 @Min(value=18, message="age sholud be more 17")
	@Max(value=100,message="age should less tha 101")
		private int age;
	
	
	////generate setter and getter method
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
