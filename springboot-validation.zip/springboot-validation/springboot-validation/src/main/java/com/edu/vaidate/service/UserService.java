package com.edu.vaidate.service;

import com.edu.vaidate.entity.User;

public interface UserService {

	User createUser(User user);

	
}
