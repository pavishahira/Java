package com.Project1;

public class NoOfDigitalMain {

	public static void main(String[] args) {
		int num=23451,c=0;
		while(num>0) {
			num=num/10;
		System.out.println(num);
		c++;
		}
	System.out.println("Num of digits="+c);
}
}