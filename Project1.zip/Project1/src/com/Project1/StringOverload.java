package com.Project1;

public class StringOverload {
	 void check(String str,char ch) {
		int count=0;
		for(int i=0;i<str.length();i++) {
			char Char=str.charAt(i);
			if(Char==ch) {
				count++;
			}
		}
		System.out.println("no of" +ch+  "present is="  +count+ "times");
	}
	 void check(String s1) {
		String s=s1.toLowerCase();
		System.out.println("vowels present in a string");
		for(int i=0;i<s1.length();i++) {
			 char ch=s1.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				System.out.println(ch+",");	
			}
		}
    }
	 public void reversestr(String s) {
		 for(int i=s.length()-1;i>=0;i--) {
			 System.out.println(s.charAt(i));
		 }
		 System.out.println();
	 }
	public static void main(String[] args) {
		StringOverload ob=new StringOverload();
		ob.check("overload", 'o');
		ob.check("overloaded");
		ob.reversestr("bookfair");
	}

}
