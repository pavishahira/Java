package demotest;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCasePgm {

static void beforeAll() {
	System.out.println("connect to the database");
}
void beforeEach() {
	System.out.println("load the schema");
}
void afterEach() {
	System.out.println("drop the schema");
}
static void afterAll() {
	System.out.println("Disconnect from the database");
}
 void testOne() {
	 System.out.println("test one");
 }
 void testTwo() {
	 System.out.println("test two");
 }
	
	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
