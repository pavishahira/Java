package com.Inheritance;
class Parent{
	void show() {
		System.out.println("parent class");	}
}
class Child extends Parent{
	void show() {
		System.out.println("child class");
		super.show();
	}
}

public class FunctionOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Child ob=new Child();
ob.show();
	}

}
