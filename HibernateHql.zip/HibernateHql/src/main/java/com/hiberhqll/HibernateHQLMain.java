package com.hiberhqll;

import java.util.Scanner;

import org.hibernate.SessionFactory;

public class HibernateHQLMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		SessionFactory sf=HibernateUtil.getSessionFact();
		while(true) {
		System.out.println("***menu***");
		System.out.println("1.Add");
		System.out.println("2.get record");
		System.out.println("3.get record by ID");
		System.out.println("4.update record");
		System.out.println("5.delete record");
		System.out.println("enter ur choice");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			HibernateOperations.Add(sf);
			break;
		case 2:
			HibernateOperations.getRecord(sf);
			break;
		case 3:
			HibernateOperations.getRecordById(sf);
			break;
		case 4:
			HibernateOperations.updateRecord(sf);
			break;
		case 5:
			HibernateOperations.deleteRecord(sf);
			break;
			default:
				System.out.println("invalid input");
				break;
		}
	System.out.println("Do you want to continue ,press any key to continue and 'n' to stop");
		char ch1=sc.next().charAt(0);
		if(ch1=='n') {
			break;
		} //if
}
System.out.println("pgm terminated");
}
}

