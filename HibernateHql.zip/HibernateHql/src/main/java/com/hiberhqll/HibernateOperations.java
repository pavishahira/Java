package com.hiberhqll;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class HibernateOperations {

	public static void Add(SessionFactory sf) {
	System.out.println("add");
	//session ss=sf.openSession();
	try(Session ss=sf.openSession()){
		Transaction t=ss.beginTransaction();
		
		EmployeeHQL en=new EmployeeHQL();
		en.setEmployeeName("divya");
		en.setEmployeeSalary(67880f);
		ss.save(en);
		
		EmployeeHQL em=new EmployeeHQL();
		em.setEmployeeName("dinesh");
		em.setEmployeeSalary(67890f);
		ss.save(em);
		
		EmployeeHQL es=new EmployeeHQL();
		es.setEmployeeName("sri");
		es.setEmployeeSalary(67990f);
		ss.save(es);
		t.commit();
		
	}
	}

	public static void getRecord(SessionFactory sf) {
		System.out.println("get record");
		try(Session ss=sf.openSession()){
			Transaction t=ss.beginTransaction();
			String sql="FROM EmployeeHQL";
			Query<EmployeeHQL> list=ss.createQuery(sql,EmployeeHQL.class); 
			List<EmployeeHQL> l=list.list();
			Iterator<EmployeeHQL> it=l.iterator();
			System.out.println("ID\tName\tSalary");
			
			while(it.hasNext()) {
			EmployeeHQL eob=it.next();	
			
				System.out.println(eob.getEmployeeId()+"\t"+eob.getEmployeeName()+"\t"+eob.getEmployeeSalary());
			}//while
		}//try			
		
	}//getRecords

	public static void getRecordById(SessionFactory sf) {
	System.out.println("get record by id");
	try(Session session=sf.openSession()){
		//get employee
		String sel="FROM EmployeeHQL where employeeId=:id";
		Query<EmployeeHQL> q=session.createQuery(sel, EmployeeHQL.class);
		q.setParameter("id", 1); //position starts 0
		EmployeeHQL eob=q.uniqueResult(); //singleresult
		System.out.println(eob);
		
	}

		
	}

	public static void updateRecord(SessionFactory sf) {
		System.out.println("update record");
try(Session session=sf.openSession()){
			
			Transaction tx=session.beginTransaction();
			Query q=session.createQuery("update EmployeeHQL set employeeName=:n where employeeId=:i");  
			q.setParameter("n","viji");  
			q.setParameter("i",1);  
			  
			int status=q.executeUpdate();  
			if(status>1) {
			System.out.println(status +"Record updated");  
			tx.commit();  

			}
		}
		
	}


	public static void deleteRecord(SessionFactory sf) {
	System.out.println("delete record");
	try(Session session=sf.openSession()){
		
		Transaction tx=session.beginTransaction();
		Query q=session.createQuery("delete from EmployeeHQL where employeeId=2");  
		//specifying class name (Emp) not tablename  
		
		int status=q.executeUpdate();  
		if(status>1) {
		System.out.println(status +"Record deleted");  
		tx.commit();  

		}
		
	}
}

	}


