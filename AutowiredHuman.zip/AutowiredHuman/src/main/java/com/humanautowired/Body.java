package com.humanautowired;

import org.springframework.beans.factory.annotation.Autowired;

public class Body {
/*@Autowired
private Heart heart; 

*/ //second

/*
 private Heart heart; 
 @Autowired //First 
public void setHeart(Heart heart) {
	this.heart = heart;
}
public Heart getHeart() {
	return heart;
}*/
	
//Third 
private Heart heart; 
	
@Autowired	
public Body(Heart heart) {
	super();
	this.heart = heart;
}

public Heart getHeartObject() {
	return heart;
}

public void humanBody() {
	heart.heartMethod();
}

}


