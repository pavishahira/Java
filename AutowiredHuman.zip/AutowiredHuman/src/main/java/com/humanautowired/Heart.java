package com.humanautowired;

public class Heart {

	public void heartMethod() {
		System.out.println("Heart is functioning");
		
	}

}
