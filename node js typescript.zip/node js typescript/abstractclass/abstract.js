"use strict";
exports.__esModule = true;
exports.Shape = void 0;
var Shape = /** @class */ (function () {
    function Shape(x, y) {
        this.x = x;
        this.y = y;
    }
    Shape.prototype.disp = function () {
        console.log("Display method");
        console.log("x=" + this.x + "  " + "y=" + this.y);
    };
    return Shape;
}());
exports.Shape = Shape;
