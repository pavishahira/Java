import{Shape} from "./abstract";
class Rectangle extends Shape{
    ar: number;
    constructor(x:number,y:number, private w:number,private h:number){
        super(x,y);
    }
    calculateArea(): number {
        this.ar=this.w*this.h;
        return this.ar;
    }
    
}
let rob=new Rectangle(4,5,3,6);
console.log("area="+rob.calculateArea());
rob.disp();