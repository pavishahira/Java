export abstract class Shape{
    private x:number;
    private y:number;

    constructor(x:number, y:number){
        this.x=x;
        this.y=y;
    }

abstract calculateArea():number;  //abstract

disp():void{ //non abstract method
    console.log("Display method")
    console.log("x="+this.x+ "  "+"y="+this.y)
}
}
