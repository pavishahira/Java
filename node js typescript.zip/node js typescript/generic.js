//Generic function
function getItems(items) {
    return new Array().concat(items);
}
var concatResult = getItems([1, 2, 3, 4, 5]);
var concatString = getItems(["a", "b", "c", "d"]);
console.log(concatResult);
console.log(concatString);
