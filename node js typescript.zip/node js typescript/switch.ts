// let day:string;
// day="monday";
// switch(day){
//     case "monday":console.log("First day of the wek");
//     break;
//     case "tuesday":console.log("second day of the wek");
//     break;
//     case "wednesday":console.log("third day of the wek");
//     break;
//     case "thursday":console.log("Fourth day of the wek");
//     break;
//     case "friday":console.log("Fiveth day of the wek");
//     break;
//     default:console.log("invalid day")
// }

let day:number;
day=3;
switch(day){
    case 1:console.log("First day of the wek");
    break;
    case 2:console.log("second day of the wek");
    break;
    case 3:console.log("third day of the wek");
    break;
    case 4:console.log("Fourth day of the wek");
    break;
    case 5:console.log("Fiveth day of the wek");
    break;
    default:console.log("invalid day")
}
