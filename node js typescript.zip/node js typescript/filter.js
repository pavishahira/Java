var list1 = [3, 4, 2, 7];
var list2 = [5, 9, 3, 8];
//find filter
list1.filter(function (num) {
    return num > 4;
});
var results = list1.filter(function (num) { return num > 4; });
console.log(results);
