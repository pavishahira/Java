var n1;
var n2;
var s;
n1 = 5;
n2 = 10;
s = n1 + n2;
console.log("sum=" + s);
