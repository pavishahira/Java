var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
function add31(n1, n2) {
    var n3 = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        n3[_i - 2] = arguments[_i];
    }
    return n1 + n2 + n3.reduce(function (a, b) { return a + b; }, 0);
}
var numbers1 = [1, 2, 3];
console.log(add31.apply(void 0, __spreadArray([2, 3], numbers1, false)));
//console.log(add31(3+4,...[8,1,1]))
