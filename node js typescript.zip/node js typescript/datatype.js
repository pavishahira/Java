var n;
var s;
var b;
b = true;
var k;
k = 90;
k = "hello";
k = 8.9;
k = 'c';
//array
var emplist;
emplist = ["pavi", "dinesh"];
console.log(emplist);
emplist = [4, 5, 6, 3, 2];
console.log(emplist);
var e = [5, 4, 7, 6, 2];
console.log(e);
var deplist; //generics
deplist = [1, 8, 5, 9];
var results = deplist.filter(function (num) { return num > 2; });
console.log(results);
var num1 = deplist.find(function (num1) { return num1 === 1; });
console.log(num1);
var sum = deplist.reduce(function (acc, num) { return acc + num; }); //finds the sum of all array elements
console.log("sum=" + sum);
