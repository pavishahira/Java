var Customer = /** @class */ (function () {
    function Customer(cid, cname) {
        this.cid = cid;
        this.cname = cname;
    }
    /*constructor(private cid:number, private cname:string){}*/
    Customer.prototype.display = function () {
        console.log("name=" + this.cname);
    };
    return Customer;
}());
var cob = new Customer(12, "deepu"); //call const
/*cob.cid=12;
cob.cname="Ravi";
console.log("name="+cob.cname)*/
cob.display();
