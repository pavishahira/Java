var fn;
var sn;
fn = 90;
sn = 99;
if (fn > sn) {
    console.log("largest of" + fn + " and" + sn + "is" + fn);
}
else {
    console.log("largest of" + fn + " and" + sn + "is" + sn);
}
