let sportsOne:string[]=["golf","tennis","cricket"];
for(let tempSport of sportsOne){
    if(tempSport=="tennis"){
        console.log(tempSport+"<<my fav!");
    }
    else{
        console.log(tempSport);
    }
}