//default parameter function required parameter
function add2(num1:number,num2:number, num3=10):number{
       return (num1+num2+num3)  //if num3 is passed it will take that value otherwise it will take the value as 10
}
console.log(add2(7,9));//here also you can pass 3 or 2 parameters
console.log(add2(7,9,12));//here also you can pass 3 or 2 parameters
