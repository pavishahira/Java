class Person{
    protected fname:string;
    protected lname:string;

    constructor(fname:string,lname:string){
        this.fname=fname;
        this.lname=lname;
    }
}

class Employee extends Person{
    private ejob:string;
    constructor(fname:string,lname: string,ejob:string){
        super(fname,lname);
        this.ejob=ejob;
    }
    display():void{
        console.log(this.fname)
    }
}

let eob=new Employee("kiran","patil","manager");
eob.display();
