class Customer{
    private cid:number;
    private cname:string;
   
      constructor(cid:number,cname:string){
       this.cid=cid;
       this.cname=cname;
      }
   
      /*constructor(private cid:number, private cname:string){}*/
   
      display():void{
       console.log("name="+this.cname);
      }
   
   }
   
   let cob=new Customer(12,"pavi"); //call const
   /*cob.cid=12;
   cob.cname="Ravi";
   console.log("name="+cob.cname)*/
   cob.display();
   