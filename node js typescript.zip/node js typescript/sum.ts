let n1:number;
let n2:number;
let s:number;
n1=5;
n2=10;
s=n1+n2;
console.log("sum="+s);