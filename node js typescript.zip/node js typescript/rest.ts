function add31(n1:number,n2:number,...n3:number[]):number{
    return n1+n2+n3.reduce((a,b) => a+b,0);
}

let numbers1=[1,2,3];
console.log(add31(2,3,...numbers1));
//console.log(add31(3+4,...[8,1,1]))