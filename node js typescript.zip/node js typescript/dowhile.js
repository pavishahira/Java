var i;
i = 1;
do {
    console.log(i);
    i = i + 1;
} while (i < 4);
