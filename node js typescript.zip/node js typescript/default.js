//default parameter function required parameter
function add2(num1, num2, num3) {
    if (num3 === void 0) { num3 = 10; }
    return (num1 + num2 + num3); //if num3 is passed it will take that value otherwise it will take the value as 10
}
console.log(add2(7, 9)); //here also you can pass 3 or 2 parameters
console.log(add2(7, 9, 12)); //here also you can pass 3 or 2 parameters
