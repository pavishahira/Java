var sportsOne = ["golf", "tennis", "cricket"];
for (var _i = 0, sportsOne_1 = sportsOne; _i < sportsOne_1.length; _i++) {
    var tempSport = sportsOne_1[_i];
    if (tempSport == "tennis") {
        console.log(tempSport + "<<my fav!");
    }
    else {
        console.log(tempSport);
    }
}
