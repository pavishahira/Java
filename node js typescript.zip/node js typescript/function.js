/*function add(n1:number,n2:number):number{
    return(n1+n2);
}
//call the fn
console.log(add(7,5));
//or
let ans:number;
console.log(ans);
*/
var add = function (n1, n2) { return n1 + n2; };
console.log(add(9, 5));
var mul = function (n1, n2) { return n1 * n2; };
console.log(mul(9, 5));
