let list1:number[]=[3,4,2,7];
let list2:Array<number>=[5,9,3,8];
//find filter
list1.filter(function(num){return num>4;
}
);
var results=list1.filter(function(num){return num>4});
console.log(results);


