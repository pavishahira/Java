class funover{
    add(n1:number,n2:number):number;
    add(n1:string,n2:string):string;
    add(n1:any,n2:any):any{
        return n1+n2;
    }
}
let fob=new funover();
console.log(fob.add(2,6));
console.log("hello", "hi");
