let i:number;
i=1;
while(i<=4){
    console.log(i);
    i=i+1;
}