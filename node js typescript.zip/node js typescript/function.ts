/*function add(n1:number,n2:number):number{
    return(n1+n2);
}
//call the fn
console.log(add(7,5));
//or
let ans:number;
console.log(ans);
*/
const add=(n1:number,n2:number):number=>n1+n2;
console.log(add(9,5));

const mul=(n1:number,n2:number):number=>n1*n2;
console.log(mul(9,5));

