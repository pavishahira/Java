//optional parameters ,here num3 is optional parameter, either you can pass or not it will work
function add1(num1, num2, num3) {
    return num3 ? (num1 + num2 + num3) : (num1 + num2);
    //if num3 exists(num1+num2+num3) else num1+num2
}
console.log(add1(7, 9, 8)); //here you can pass 2 or 3 values with optional
console.log(add1(6, 4));
