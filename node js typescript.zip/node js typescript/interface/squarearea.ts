import{shape} from "./shapeint";
class Square implements shape{
    private side:number;
    constructor(side:number){
        this.side=side;
    }
    calarea():void{
        console.log("area of square="+(this.side*this.side))
    }
}
let sob=new Square(7);
sob.calarea();