"use strict";
exports.__esModule = true;
var Square = /** @class */ (function () {
    function Square(side) {
        this.side = side;
    }
    Square.prototype.calarea = function () {
        console.log("area of square=" + (this.side * this.side));
    };
    return Square;
}());
var sob = new Square(7);
sob.calarea();
