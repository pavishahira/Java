export interface shape{
    calarea():void;
}