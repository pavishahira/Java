package com.HelloWorld;

public class NameAddress {
	public static void main(String[] args) {
System.out.println("Pavithra");
System.out.println("Nagercoil");
}
}
