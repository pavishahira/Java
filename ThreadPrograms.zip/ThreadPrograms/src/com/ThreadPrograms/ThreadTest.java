package com.ThreadPrograms;
class Thread11 extends Thread{
	 public void run() {
		 for(int i=1;i<=5;i++) {
				System.out.println("name="+Thread.currentThread());
				System.out.println(i);
				
				
			 }
		}
	

synchronized public void display() {

	
}
}
public class ThreadTest {

	public static void main(String[] args) throws InterruptedException  {
		
Thread11 ob=new Thread11();
   ob.setName("anu");
   Thread11 ob1=new Thread11();
   ob1.setName("abi");
   
   ob.start();
 ob.join();
   ob1.start();
  
  
   
	}

}
