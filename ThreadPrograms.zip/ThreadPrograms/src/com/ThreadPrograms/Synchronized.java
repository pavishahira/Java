package com.ThreadPrograms;
class SynchronizedEx{
	synchronized void show(String p) {
		try {
			System.out.println("***");
			System.out.println(p);
			Thread.sleep(1000);
			System.out.println("####");
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
class MyPgms implements Runnable{
	Thread c;
	String m;
	SynchronizedEx r;
	MyPgms(SynchronizedEx w,String k){
		r=w;m=k;
		c=new Thread(this);
	}
	public void run() {
		r.show(m);
	}
	}
public class Synchronized{
	public static void main(String[] args)throws InterruptedException{
		SynchronizedEx d=new SynchronizedEx();
		MyPgms t1=new MyPgms(d,"hello");
		MyPgms t2=new MyPgms(d,"java");
		t1.c.start();
		t2.c.start();
		t1.c.join();
		t2.c.join();
	}
}