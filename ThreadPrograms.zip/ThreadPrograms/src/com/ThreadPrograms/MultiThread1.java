package com.ThreadPrograms;
public class MultiThread1 {

	public static void main(String[] args) {
		MultiThread ob=new MultiThread("Thread1");
		ob.start();
		MultiThread ob1=new MultiThread("Thread2");
		ob1.start();
}
}
class MultiThread implements Runnable{
	Thread cooking;
	private String IOT;
	MultiThread(String name){
		IOT=name;
	}
	public void run() {
		System.out.println("Thrad running"+IOT);
		for(int i=0;i<4;i++) {
			System.out.println(i);
			System.out.println(IOT);
			try {
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {
				System.out.println("Thread is interrupted");
			}
		}
	}
	public void start() {
		System.out.println("Thread started");
		if(cooking==null) {
			cooking=new Thread(this,IOT);
			cooking.start();
		}
	}
}
