package com.demospring.service;

import com.demospring.entity.Department;

public interface DepartmentService {

public 	Department saveDepartment(Department department);

}
