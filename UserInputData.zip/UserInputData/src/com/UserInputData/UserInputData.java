package com.UserInputData;

import java.util.Scanner;

public class UserInputData {

	public static void main(String[] args) {
	Scanner	sc=new Scanner(System.in);
	int i;
	float f;
	double d;
	byte b;
	short s;
	char ch;
	String fname;
	String fnln;
	System.out.println("name=");
	fname=sc.next();
	System.out.println("int=");
	i=sc.nextInt();
	System.out.println("short=");
	s=sc.nextShort();
	System.out.println("byte=");
	b=sc.nextByte();
	System.out.println("float=");
	f=sc.nextFloat();
	System.out.println("double=");
	d=sc.nextDouble();
	System.out.println("char=");
	ch=sc.next().charAt(0);
	System.out.println("name"+fname);
	System.out.println("int"+i);
	System.out.println("short"+s);
	System.out.println("byte"+b);
	System.out.println("double"+d);
	System.out.println("char"+ch);
	
	
	

	}

}
