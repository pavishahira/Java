package com.edubridge.empmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagement78837887BatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagement78837887BatchApplication.class, args);
	}

}
