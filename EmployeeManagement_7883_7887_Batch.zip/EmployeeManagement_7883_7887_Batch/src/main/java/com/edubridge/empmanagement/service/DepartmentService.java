package com.edubridge.empmanagement.service;

import java.util.List;

import com.edubridge.empmanagement.entity.Department;
import com.edubridge.empmanagement.error.DepartmentNotFoundException;



public interface DepartmentService {

	public Department saveDepartment(Department department);

	public Department getDepartmentById(Long departmentId) throws DepartmentNotFoundException;

	public void departmentDeleteById(Long departmentId) throws DepartmentNotFoundException;

	public Department departmentUpdateById(Long departmentId, Department department) throws DepartmentNotFoundException;

	public List<Department> getAllDepartments();

	public Department getDepartmentByName(String departmentName);

	public List<Department> getAllDepartmentsQuery();

	//public Department employeeAssignDepartment(Long employeeId, Long departmentId);

	
	

	
	}



	

	



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//public Department saveDepartment(Department department); //all abstract method

	//public Department getDepartmentByName(String departmentName);


