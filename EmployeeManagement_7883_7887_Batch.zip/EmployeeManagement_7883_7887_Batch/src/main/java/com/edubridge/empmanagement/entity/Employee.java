package com.edubridge.empmanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.criteria.Fetch;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Employee{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name="Seq", initialValue=1111)
	
    //@Column(name = "id", updatable = false, nullable = false)
   private Long employeeId;

	@NotBlank(message = "Please enter name")
	@Size(min=4, message = "Name should be atleast 4 characters")
	@Size(max=10, message = "Name should not be greater than 10 characters")
	private String employeeName;
	
	@Min(value=1000, message = "Salary must be atleast 1000.00")
	@Max(value=10000, message = "Salary should not be greater than 10000.00")
	private Float employeeSalary;
	
	@Email(message = "Please enter valid email", regexp="^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
	@NotNull(message = "Please enter email")
	@Column(unique = true)
	private String employeeEmail;
  
   private Integer employeeStatus;
   @Column(unique = true)
   private Long employeePhone;
   
      
  ///many employees in one department
   @ManyToOne(cascade = CascadeType.ALL) //Many employee one dept
   @JoinColumn(name="deptpartment_Id", referencedColumnName = "departmentId")
   @JsonIgnore
 
   private Department dept;
   
     
   
public Department getDepartment() {
	return dept;
}
public void setDepartment(Department department) {
	this.dept = department;
}
//////////////////
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(Long employeeId, String employeeName, Float employeeSalary, Long departmentId, Integer employeeStatus,
		Long employeePhone, String employeeEmail) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeSalary = employeeSalary;
	this.employeeStatus = employeeStatus;
	this.employeePhone = employeePhone;
	this.employeeEmail = employeeEmail;
	
}
public Long getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(Long employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Float getEmployeeSalary() {
	return employeeSalary;
}
public void setEmployeeSalary(Float employeeSalary) {
	this.employeeSalary = employeeSalary;
}

public Integer getEmployeeStatus() {
	return employeeStatus;
}
public void setEmployeeStatus(Integer employeeStatus) {
	this.employeeStatus = employeeStatus;
}
public Long getEmployeePhone() {
	return employeePhone;
}
public void setEmployeePhone(Long employeePhone) {
	this.employeePhone = employeePhone;
}
public String getEmployeeEmail() {
	return employeeEmail;
}
public void setEmployeeEmail(String employeeEmail) {
	this.employeeEmail = employeeEmail;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
			+ employeeSalary + ", employeeEmail=" + employeeEmail + ", employeeStatus=" + employeeStatus
			+ ", employeePhone=" + employeePhone + "]";
}
public void employeeAssignDepartment(Department department) {
	this.dept=department;
	
}


   
   
   
}