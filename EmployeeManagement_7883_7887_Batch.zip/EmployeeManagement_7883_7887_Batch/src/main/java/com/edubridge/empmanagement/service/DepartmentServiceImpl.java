package com.edubridge.empmanagement.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.websocket.DeploymentException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.edubridge.empmanagement.entity.Department;
import com.edubridge.empmanagement.entity.Employee;
import com.edubridge.empmanagement.error.DepartmentNotFoundException;
import com.edubridge.empmanagement.repository.DepartmentRepository;
import com.edubridge.empmanagement.repository.EmployeeRepository;


@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Department saveDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentRepository.save(department);
	}
	@Override
	public Department getDepartmentById(Long departmentId) throws DepartmentNotFoundException  {
		// TODO Auto-generated method stub
		//return departmentRepository.findById(departmentId).get();
		 //Optional<Department> dept=departmentRepository.findById(departmentId); //java 8
		Optional<Department> dept=departmentRepository.findById(departmentId) ;
		
		 if(!dept.isPresent()) {
			 throw new DepartmentNotFoundException("Department Not Found");
		 }
		 return departmentRepository.findById(departmentId).get();
	}
	@Override
	public void departmentDeleteById(Long departmentId) throws DepartmentNotFoundException  {
	//	departmentRepository.deleteById(departmentId);
		Optional<Department> dept=departmentRepository.findById(departmentId) ;
		if(!dept.isPresent()) {
			 throw new DepartmentNotFoundException("Department Not Found");
		 }
		departmentRepository.deleteById(departmentId);
		
	}
	@Override
	public Department departmentUpdateById(Long departmentId, Department department) throws DepartmentNotFoundException {
		//get the record from the table
		// TODO Auto-generated method stub//jdk 1.8 new feature
		Optional<Department> dept=departmentRepository.findById(departmentId) ;
		Department deptDB;
		if(!dept.isPresent()) {
			 throw new DepartmentNotFoundException("Department Not Found");
		 }
		
		 else{
		         deptDB=departmentRepository.findById(departmentId).get();
				
				if(Objects.nonNull(department.getDepartmentName()) &&
				!"".equalsIgnoreCase(department.getDepartmentName())) {
					deptDB.setDepartmentName(department.getDepartmentName());
				}
				if(Objects.nonNull(department.getDepartmentCode()) &&
						!"".equalsIgnoreCase(department.getDepartmentCode())) {
							deptDB.setDepartmentCode(department.getDepartmentCode());
						}
				if(Objects.nonNull(department.getDepartmentLocation()) &&
						!"".equalsIgnoreCase(department.getDepartmentLocation())) {
							deptDB.setDepartmentLocation(department.getDepartmentLocation());
						}
					}
				return departmentRepository.save(deptDB);
				
	}
	@Override
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return departmentRepository.findAll();
	}
	@Override
	public Department getDepartmentByName(String departmentName) {
		// TODO Auto-generated method stub
		return departmentRepository.findByDepartmentName(departmentName);
	}
	@Override
	public List<Department> getAllDepartmentsQuery() {
		// TODO Auto-generated method stub
		return departmentRepository.findAllDepartmentQuery();
	}
	
	
	
}
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	

