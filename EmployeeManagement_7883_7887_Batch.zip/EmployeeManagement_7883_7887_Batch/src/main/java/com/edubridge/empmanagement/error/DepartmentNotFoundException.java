package com.edubridge.empmanagement.error;

public class DepartmentNotFoundException extends Exception{
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DepartmentNotFoundException(String s) {
		super(s);
	}

}
