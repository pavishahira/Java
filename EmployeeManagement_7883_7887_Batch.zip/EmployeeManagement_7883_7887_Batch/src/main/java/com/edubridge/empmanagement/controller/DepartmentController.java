package com.edubridge.empmanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.edubridge.empmanagement.entity.Department;
import com.edubridge.empmanagement.error.DepartmentNotFoundException;
import com.edubridge.empmanagement.service.DepartmentService;

@RestController //
public class DepartmentController {
	//Inject an object of DepartmentService
	@Autowired
	private DepartmentService departmentService;
	private final Logger LOGGER= LoggerFactory.getLogger(DepartmentController.class);
	
	//save the record
	                              //post
	@PostMapping("/departments")  //http://localhost:portno/departments
	public Department saveDepartment(@RequestBody Department department) {
		LOGGER.info("Inside saveDept");
		return departmentService.saveDepartment(department);
	}
	
	//get  records by id
	
	@GetMapping("/departments/{deptid}") //http://localhost:8889/departments/1
	public Department getDepartmentById(@PathVariable("deptid") Long departmentId) throws DepartmentNotFoundException {
		

		return departmentService.getDepartmentById(departmentId);
	}
	
	
	
	
	
	//get all departments
	@GetMapping("/getAllDepartments")
	public List<Department> getAllDepartments(){
		return departmentService.getAllDepartments();
		
	}
	
	//findAllDepartments Query Method
	@GetMapping("/getAllDepartmentsQueryMethod")
	public List<Department> getAllDepartmentsQuery(){
		return departmentService.getAllDepartmentsQuery();
	}
	
	
	
	
	
	
	@DeleteMapping("/departments/{deptid}")
	public String departmentDeleteById(@PathVariable("deptid") Long departmentId) throws DepartmentNotFoundException {
		departmentService.departmentDeleteById(departmentId);
		return "Department is deleted";
	}
	
	
	
	
	
	
	
	
	
	
	
	//update Department
	@PutMapping("/departments/{deptid}")
	public Department departmentUpdateById(@PathVariable("deptid") Long departmentId,@RequestBody Department department ) throws DepartmentNotFoundException {
		
		return departmentService.departmentUpdateById(departmentId,department);
	}
	
	//find ByName
			@GetMapping("/departments/deparmentname/{deptname}")
					
			public Department getDepartmentByName(@PathVariable("deptname") String departmentName) {
			
			  return departmentService.getDepartmentByName(departmentName);
			}
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	