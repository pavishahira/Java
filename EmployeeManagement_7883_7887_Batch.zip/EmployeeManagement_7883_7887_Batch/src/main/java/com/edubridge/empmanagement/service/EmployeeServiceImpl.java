package com.edubridge.empmanagement.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.empmanagement.entity.Department;
import com.edubridge.empmanagement.entity.Employee;
import com.edubridge.empmanagement.error.EmployeeNotFoundException;
import com.edubridge.empmanagement.repository.DepartmentRepository;
import com.edubridge.empmanagement.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
	private EmployeeRepository employeeRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}
	@Override
	public Employee getEmployeeById(Long employeeId) throws EmployeeNotFoundException  {
		// TODO Auto-generated method stub
		Optional<Employee> emp=employeeRepository.findById(employeeId);
		if(!emp.isPresent()) {
			throw new EmployeeNotFoundException("Employee Not Found");
		}
		
		return employeeRepository.findById(employeeId).get();
	}
	@Override
	public Employee updateEmployeeById(Long employeeId, Employee employee) throws EmployeeNotFoundException  {

	//get the record from the table
				// TODO Auto-generated method stub//jdk 1.8 new feature
				Optional<Employee> emp=employeeRepository.findById(employeeId) ;
				Employee empDB=null;
				if(!emp.isPresent()) {
					 throw new EmployeeNotFoundException("Department Not Found");
				}
				
			 else{
					 empDB =employeeRepository.findById(employeeId).get();
						
						if(Objects.nonNull(employee.getEmployeeName()) &&
						!"".equalsIgnoreCase(employee.getEmployeeName())) {
							empDB.setEmployeeName(employee.getEmployeeName());
						}
						if(Objects.nonNull(employee.getEmployeeSalary()) ) {
							empDB.setEmployeeSalary(employee.getEmployeeSalary());
						}
						if(Objects.nonNull(employee.getEmployeeStatus())) {
									empDB.setEmployeeStatus(employee.getEmployeeStatus());
								}
						if(Objects.nonNull(employee.getDepartment())) {
							empDB.setDepartment(employee.getDepartment());
						}
						if(Objects.nonNull(employee.getEmployeePhone())) {
							empDB.setEmployeePhone(employee.getEmployeePhone());
						}
						
						if(Objects.nonNull(employee.getEmployeeEmail()) &&
						!"".equalsIgnoreCase(employee.getEmployeeEmail())) {
							empDB.setEmployeeEmail(employee.getEmployeeEmail());
						}
						
					}//else
				return employeeRepository.save(empDB);
	}
	@Override
	public void deleteEmployeeById(Long employeeId) throws EmployeeNotFoundException {
		Optional<Employee> emp=employeeRepository.findById(employeeId);
		
		if(!emp.isPresent()) {
			throw new EmployeeNotFoundException("Employee Id Not present");
		}
		employeeRepository.deleteById(employeeId);
		
	}
	@Override
	public List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}
	@Override
	public List<Employee> findEmployeeByName(String employeeName) {
		// TODO Auto-generated method stub
		return employeeRepository.findByEmployeeName(employeeName);
	}
	@Override
	public Employee findByEmployeeEmail(String employeeEmail) {
		// TODO Auto-generated method stub
		return employeeRepository.findByEmployeeEmail(employeeEmail);
	}
///////////////New Code
@Override
public Employee employeeAssignDepartment(Long employeeId, Long departmentId) {
Department department=departmentRepository.findById(departmentId).get();
Employee employee=employeeRepository.findById(employeeId).get();
employee.employeeAssignDepartment(department);
return employeeRepository.save(employee);
}
	
}


