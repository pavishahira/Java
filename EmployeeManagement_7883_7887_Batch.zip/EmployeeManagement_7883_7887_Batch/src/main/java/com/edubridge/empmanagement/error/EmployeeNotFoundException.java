package com.edubridge.empmanagement.error;

public class EmployeeNotFoundException extends Exception{
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeNotFoundException(String s) {
		super(s);
	}

}
