package com.edubridge.empmanagement.service;

import java.util.List;

import com.edubridge.empmanagement.entity.Employee;
import com.edubridge.empmanagement.error.EmployeeNotFoundException;



public interface EmployeeService {

public Employee addEmployee(Employee employee);

public Employee getEmployeeById(Long employeeId) throws EmployeeNotFoundException;

public Employee updateEmployeeById(Long employeeId, Employee employee) throws EmployeeNotFoundException;

public void deleteEmployeeById(Long employeeId) throws EmployeeNotFoundException;

public List<Employee> findAllEmployee();

public List<Employee> findEmployeeByName(String employeeName);

public Employee findByEmployeeEmail(String employeeEmail);

public Employee employeeAssignDepartment(Long employeeId, Long departmentId);

}
