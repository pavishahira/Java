package com.edubridge.empmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edubridge.empmanagement.entity.Department;


@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

	Department findByDepartmentName(String departmentName);

	//Query Method
	@Query("select d from Department d")
	public List<Department> findAllDepartmentQuery();
     
}
