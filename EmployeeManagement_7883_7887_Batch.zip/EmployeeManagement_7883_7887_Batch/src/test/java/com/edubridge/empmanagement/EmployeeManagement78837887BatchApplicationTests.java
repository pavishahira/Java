package com.edubridge.empmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagement78837887BatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
