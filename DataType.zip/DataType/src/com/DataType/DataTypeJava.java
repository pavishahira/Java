package com.DataType;

public class DataTypeJava {

	public static void main(String[] args) {
		int i=12;
		byte b=123;
		float f=34.3f;
		short s=23;
		double d=345.231;
		char ch='A';
		char chr=67;
		boolean bool=true;
		System.out.println("int"+i);
		System.out.println("byte"+b);
		System.out.println("float"+f);
		System.out.println("short"+s);
		System.out.println("double"+d);
		System.out.println("char"+ch);
		System.out.println("char value using ascii"+chr);
		System.out.println("boolean"+bool);
	}

}
