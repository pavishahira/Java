package com.DataType;

public class Test {

	public static void main(String[] args) {
		byte a,b,c;
		a=123;
		b=48;
		c=(byte)(a+b);
		System.out.println("c="+c);
	}

}
