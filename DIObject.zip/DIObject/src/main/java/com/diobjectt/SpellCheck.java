package com.diobjectt;

public class SpellCheck {
	
	public SpellCheck() {
		super();
		System.out.println("Inside spellcheck Constructor");
	}

	public void checkSpelling() {
		System.out.println("Checking Spelling");
		
	}

}


