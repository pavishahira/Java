package com.diobjectt;

public class TextEditor {
	private SpellCheck spellcheck;

	public TextEditor(SpellCheck spellcheck) {
		super();
		this.spellcheck = spellcheck;
		System.out.println("TextEditor Constructor");
	}

	void callSpellCheck() {
		spellcheck.checkSpelling();
	}
		

	}



