package com.spring;

public class HelloWorld {

	public void display() {
		System.out.println("hai hello");
		
	}
	}

