package package22;

public class Prodectt {

		private int pid;
		private String pname;
		public Prodectt() {
			pid=100;
			pname="tv";
			}
		public void display() {
			System.out.println("product id="+pid);
			System.out.println("product name="+pname);
		}

		}

