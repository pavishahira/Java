package package2;

public class Product {
public int pid;
public String pname;
public Product() {
	pid=2;
	pname="tv";
	}

}
