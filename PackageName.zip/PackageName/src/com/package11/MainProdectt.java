package com.package11;

import package22.Prodectt;

public class MainProdectt {

	public static void main(String[] args) {
		Prodectt ob=new Prodectt();
		ob.display();

	}

}
