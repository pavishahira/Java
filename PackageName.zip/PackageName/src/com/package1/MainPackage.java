package com.package1;

import package2.Product;

public class MainPackage {

	public static void main(String[] args) {
		Product ob=new Product();
		System.out.println("product id="+ob.pid);
		System.out.println("product name="+ob.pname);
		

	}

}
