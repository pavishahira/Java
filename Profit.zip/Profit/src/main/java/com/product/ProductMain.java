package com.product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
		import org.hibernate.Transaction;
		import org.hibernate.cfg.Configuration;

		public class ProductMain {
			public static void main(String[] args) {
			        Configuration config =new Configuration();
			        config .configure("hibernate2.cfg.xml");
			        config.addAnnotatedClass(Product1.class);
				SessionFactory sf=config.buildSessionFactory();
				Session ss=sf.openSession();
				Transaction t=ss.beginTransaction();
				Product1 pob=new Product1();
				
			    pob.setPid(1256);
				pob.setPname("powder");
				pob.setpPrice(60);
				ss.save(pob);
				t.commit();
				System.out.println("record is saved successfully");
			}

		}


	


