package com.branches;

import java.util.Scanner;

public class Maths {

	public static void main(String[] args) {
		int ch;
		float num1,num2,res;
		Scanner sc=new Scanner(System.in);
		while (true) {
        System.out.println("****Menu*****");
	  System.out.println("1.Addition");
		System.out.println("2.Substraction");
		System.out.println("3.Multiplication");
		System.out.println("4.Division");
		System.out.println("enter ur choice:");
		ch=sc.nextInt();
	    System.out.println("enter num1,num2:");
	    num1=sc.nextFloat();
	    num2=sc.nextFloat();
						switch(ch) {
						case 1: res=num1+num2;
						System.out.println("add"+res);
						break;
					    case 2: res=num1-num2;
					    System.out.println("sub "+res);
					    break;
						case 3: res=num1*num2;
						System.out.println("mul"+res );
						break;
                        case 4: if(num2==0) {
                        System.out.println("div by zero error");
                        }
                        else {
                        	res=num1/num2;
                        	System.out.println("div"+res);
                        }
						break;
					default: System.out.println("Invalid");
						}
						System.out.println("do you want to continue(y/n)");
						char choice=sc.next().charAt(0);
						if(ch=='n') {
							break;
						}
						System.out.println("program is terminated");

					}
	}

				}

