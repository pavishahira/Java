package com.branches;

import java.util.Scanner;

public class MonthOfYear {

	public static void main(String[] args) {
		String month;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter ur month:");
		month=sc.next();
		switch(month) {
		case  "january": System.out.println("First month of year" );
		break;
		case "February": System.out.println("Second month of year" );
		break;
		case "March": System.out.println("Third month of year" );
		break;
		case "April": System.out.println("Fourth month of year" );
		break;
		case "May": System.out.println("Fifth month of year" );
		break;
		case "June": System.out.println("sixth month of year" );
		break;
		case "July": System.out.println("Seventh month of year" );
		break;
		case "August": System.out.println("Eighth month of year" );
		break;
		case "September": System.out.println("Ninth month of year" );
		break;
		case "October": System.out.println("tenth month of year" );
		break;
		case "November": System.out.println("eleventh month of year" );
		break;
		case "december": System.out.println("twelveth month of year" );
		break;
		default:
			System.out.println("Invalid" );
			
		}
		

	}

}
