package com.branches;

import java.util.Scanner;

public class VowelsOrNot {

	public static void main(String[] args) {
		char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter ur choice");
		ch=sc.next().charAt(0);
		switch(ch) {
		case 'a': System.out.println("a is an viwel");
		break;
		case 'e': System.out.println("e is an viwel");
		break;
		case 'i': System.out.println("i is an viwel");
		break;
		case 'o': System.out.println("o is an viwel");
		break;
		case 'u': System.out.println("u is an viwel");
		break;
		default:
			System.out.println("Invaild");
			
		}
		

	}

}
