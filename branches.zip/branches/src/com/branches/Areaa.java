package com.branches;

import java.util.Scanner;
class Area{
	int ch;
	float length,breadth,radius,base,area,height,pi=3.14159f;
	Scanner sc=new Scanner(System.in);
	 
	public void areasquare() {
		System.out.println("enter length of the square");
		length=sc.nextFloat();
		area=length*length;
		System.out.println("area of  square"+area);
	}
	public void arearectangle() {
		System.out.println("enter length and breadth of the rectangle");
		length=sc.nextFloat();
		breadth=sc.nextFloat();
		area=length*breadth;
		System.out.println("area of  rectangle"+area);
	}
	public void areatriangle() {
		System.out.println("enter base and height of the triangle");
		base=sc.nextFloat();
		height=sc.nextFloat();
		area=base*height/2;
		System.out.println("area of  triangle"+area);
		
	}
	public void areacricle() {
		System.out.println("enter radiius circle");
		radius=sc.nextFloat();
		area=pi*radius*radius;
		System.out.println("area of  triangle"+area);
		
	}	
}
public class Areaa {

	public static void main(String[] args) {
	  int ch;
	  Area ob=new Area();
	  Scanner sc=new Scanner(System.in);
	  System.out.println("1.area of square");
	  System.out.println("2.area of rectangle");
	  System.out.println("3.area of triangle");
	  System.out.println("4.area of circle");
	  System.out.println("enter ur choice");
	  ch=sc.nextInt();
	  switch(ch) {
	  case 1: ob.areasquare();
	  break;
	  case 2: ob.arearectangle();
	  break;
	  case 3: ob.areatriangle();
	  break;
	  case 4: ob.areacricle();
	  break;
	  default:
		  System.out.println("Invaild");
	  
	  }
	  

	}

}
