package com.branches;

import java.util.Scanner;

public class Areas {

	public static void main(String[] args) {
		int ch;
		float area,length,breadth,base,height,radius;
		Scanner sc=new Scanner(System.in);
		System.out.println("****menu****");
		System.out.println("1.area ofsquare");
		System.out.println("2.area ofrectangle");
		System.out.println("3.area oftriangle");
		System.out.println("4.area of circle");
		System.out.println("enter ur choice:");;
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("square");
			length=sc.nextFloat();
			area=length*length;
			System.out.println("square"+area);
			break;
		case 2:
			System.out.println("rectangle");
			length=sc.nextFloat();
			breadth=sc.nextFloat();
			area=length*breadth;
			System.out.println("rec"+area);
			break;
		case 3:
			System.out.println("triangle");
			height=sc.nextFloat();
			base=sc.nextFloat();
			area=1/2*base*height;
			System.out.println("tri"+area);
			break;
		case 4:
			System.out.println("Cricle");
			radius=sc.nextFloat();
			area=22/7*radius*radius;
			System.out.println("Cricle"+area);
			break;
			
		default: 	System.out.println("Invalid");
		}
		
	}

}
