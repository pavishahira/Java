package com.LinkedList;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedList4 {

	public static void main(String[] args) {
		LinkedList<String>arr=new LinkedList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual Linkedlist"+arr);
		List<String>list=new ArrayList<String>();
		list.add("one");
		list.add("two");
		arr.addAll(list);
		System.out.println("after copy:"+arr);

	}

}
