package com.LinkedList;
import java.util.LinkedList;

public class LinkedList3 {

	public static void main(String[] args) {
		LinkedList<String>arr=new LinkedList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual Linkedlist"+arr);
		LinkedList<String> copy=(LinkedList<String>)arr.clone();
System.out.println("cloned linkedlist:"+copy);
	}

}
