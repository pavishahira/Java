package com.LinkedList;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedList2 {

	public static void main(String[] args) {
	LinkedList<String>arr=new LinkedList<String>();
	arr.add("first");
	arr.add("second");
	arr.add("third");
	arr.add("random");
	Iterator<String>itr=arr.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	

	}

}
