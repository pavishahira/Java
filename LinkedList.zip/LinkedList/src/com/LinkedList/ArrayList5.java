package com.LinkedList;
import java.util.LinkedList;

public class ArrayList5 {

	public static void main(String[] args) {
		LinkedList<String>arr=new LinkedList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual Linkedlist"+arr);
		arr.clear();
		System.out.println("after clear linkedlist:"+arr);

	}

}
