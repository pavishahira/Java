package com.LinkedList;
import java.util.LinkedList;

public class LinkedList1 {

	public static void main(String[] args) {
		LinkedList<String>ll=new LinkedList<String>();
		ll.add("apple");
		ll.add("grape");
		ll.add("banana");
		ll.add("orange");
		System.out.println(ll);
		System.out.println("size of the linked list"+ll.size());
		System.out.println("is linkedlist empty?"+ll.isEmpty());
		System.out.println("does linkedlist contains 'grape'?"+ll.contains("grape"));

	}

}
