package com.Designpattern;
interface AreaFig{
	void area();
}
class Rectangle implements AreaFig{
	public void area() {
		int l=7;
		int b=7;
		int a=l*b;
		System.out.println("area of rectangle:"+a);
	}
}
class Square implements AreaFig{
	public void area() {
		int l=6;
		int a=l*l;
		System.out.println("area of square:"+a);
	}
}
public class AreaDesignPattern {

	public static void main(String[] args) {
	AreaFig ob;
	ob=new Rectangle();
	ob.area();
	ob=new Square();
	ob.area();
	}
}
