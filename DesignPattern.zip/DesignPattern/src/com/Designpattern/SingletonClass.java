package com.Designpattern;
class DBClass{
	static DBClass dbobject=null;
	private DBClass() {
		System.out.println("Constructor called");
	}
	public static DBClass getObject() {
		if(dbobject==null) {
			dbobject=new DBClass();
			System.out.println("Object ref="+dbobject);
		}
		return dbobject;
	}
	public void getRecords() {
		System.out.println("function to display all Employee records");
	}
}
public class SingletonClass {
	public static void main(String[] args) {
		DBClass ob=DBClass.getObject();
		System.out.println("Main Object ref="+ob);
		ob.getRecords();
	}
}
