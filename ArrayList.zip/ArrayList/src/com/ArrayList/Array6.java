package com.ArrayList;
import java.util.ArrayList;
import java.util.List;

public class Array6 {

	public static void main(String[] args) {
		ArrayList<String>arr=new ArrayList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		List<String>list=new ArrayList<String>();
		list.add("second");
		list.add("random");
		System.out.println("does arraylist contains all list elements?:"+arr.containsAll(list));
		list.add("one");
		System.out.println("does arraylist contains all list elements?:"+arr.containsAll(list));

	}

}
