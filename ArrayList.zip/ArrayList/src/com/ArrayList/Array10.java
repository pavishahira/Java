package com.ArrayList;
import java.util.ArrayList;
import java.util.Collections;

public class Array10 {

	public static void main(String[] args) {
		ArrayList<String>list=new ArrayList<String>();
		list.add("java");
		list.add("cric");
		list.add("play");
		list.add("watch");
		list.add("glass");
		Collections.reverse(list);
		System.out.println("results after reverse opertion");
		for(String str:list) {
			System.out.println(str);
		}

	}

}
