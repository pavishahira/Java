package com.ArrayList;
import java.util.ArrayList;

public class Array1 {

	public static void main(String[] args) {
	ArrayList<String>al=new ArrayList<String>();
	al.add("java");
	al.add("c++");
	al.add("perl");
	al.add("php");
System.out.println(al);
System.out.println("element at index 1:"+al.get(1));
System.out.println("does list contains java?"+al.contains("java"));
al.add(2,"play");
System.out.println(al);
System.out.println("is arraylist empty?"+al.isEmpty());
System.out.println("indexof perl is"+al.indexOf("perl"));
System.out.println("size of the arraylist is"+al.size());
	}

}
