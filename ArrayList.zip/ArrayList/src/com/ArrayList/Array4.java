package com.ArrayList;
import java.util.ArrayList;
import java.util.List;

public class Array4 {

	public static void main(String[] args) {
		ArrayList<String>arr=new ArrayList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual arralist:"+arr);
		List<String>list=new ArrayList<String>();
		list.add("one");
		list.add("two");
		arr.addAll(list);
		System.out.println("after copy:"+arr);

	}

}
