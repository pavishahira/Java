package com.ArrayList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Array9 {

	public static void main(String[] args) {
		List<Empl> list=new ArrayList<Empl>();
		list.add(new Empl("pavi",500000));
		list.add(new Empl("anu",500000));
		list.add(new Empl("abi",500000));
		list.add(new Empl("aji",500000));
		list.add(new Empl("raji",500000));
Collections.sort(list,new MySalaryComp());
System.out.println("sorted list entries:");
for(Empl e:list) {
	System.out.println(e);
}
	}

}
class MySalaryComp implements Comparator<Empl>{

	@Override
	public int compare(Empl e1,Empl e2) {
		if(e1.getSalary() < e2.getSalary()) {
		return 1;
	}
		else {
			return -1;
		}
	}
}
class Empl{
	
	private String name;
	private int salary;
	public Empl(String n,int s) {
		this.name=n;
		this.salary=s;
	}
	public String getName() {
		return name;
		
	}
	public void setName(String name) {
		this.name=name;
	}
	public int getSalary() {
		return  salary;
	}
	public void setSalary(int Salary) {
		this.salary=salary;
	}
	public String toString() {
		return "name:"+this.name+"--Salary:"+this.salary;
	}
}
