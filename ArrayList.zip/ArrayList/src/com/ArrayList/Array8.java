package com.ArrayList;

import java.util.ArrayList;
import java.util.List;

public class Array8 {

	public static void main(String[] args) {
		ArrayList<String>arr=new ArrayList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		arr.add("click");
		System.out.println("actul arraylist:"+arr);
		List<String>list=arr.subList(2, 4);
		System.out.println("sub list"+list);

	}

}
