package com.ArrayList;
import java.util.ArrayList;

public class Array7 {

	public static void main(String[] args) {
		ArrayList<String>arr=new ArrayList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual arraylist:"+arr);
		String[] strArr=new String[arr.size()];
		arr.toArray(strArr);
		System.out.println("created array content:");
		for(String str:strArr) {
			System.out.println(str);
		}

	}

}
