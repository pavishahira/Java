package com.ArrayList;
import java.util.ArrayList;

public class Array5 {

	public static void main(String[] args) {
		ArrayList<String>arr=new ArrayList<String>();
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("random");
		System.out.println("actual arraylist:"+arr);
		arr.clear();
		System.out.println("after clear arraylist"+arr);

	}

}
