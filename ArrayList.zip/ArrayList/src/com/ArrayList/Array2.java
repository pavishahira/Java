package com.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;

public class Array2 {

	public static void main(String[] args) {
	ArrayList<String>arr=new ArrayList<String>();
	arr.add("first");
	arr.add("second");
	arr.add("third");
	arr.add("random");
	Iterator<String>itr=arr.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}

	}

}
