package com.Exercise;

public class Seventeen {
	int i;
	Seventeen(){
	System.out.println("creating no argument constructor");
	System.out.println("i="+i);
}

	public static void main(String[] args) {
	
Seventeen ob=new Seventeen();
	}

}
