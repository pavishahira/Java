package com.Exercise;

public class TwentyNine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] numbers= {1,2,3};
			System.out.println(numbers[50]);
		}
		catch(Exception e) {
			System.out.println("error in code");
		}

	}

}
