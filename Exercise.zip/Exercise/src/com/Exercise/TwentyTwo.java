package com.Exercise;
class Books{
	void run() {
		System.out.println("books not in stock");
	}
}
 
public class TwentyTwo extends Books{
	void run() {
		System.out.println("books are available");
	}

	public static void main(String[] args) {
		TwentyTwo ob=new TwentyTwo();
		ob.run();

	}

}
