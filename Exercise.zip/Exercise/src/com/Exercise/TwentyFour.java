package com.Exercise;
class App{
	public void print_App() {
		System.out.println("cooking");
	}
}
class Apps extends App{
	public void print_Apps() {
		System.out.println("emerging tech");
	}
}

public class TwentyFour {

	public static void main(String[] args) {
		Apps d=new Apps();
		d.print_App();
		d.print_Apps();

	}

}
