package com.Exercise;

public class Ten {

	public static void main(String[] args) {
		int a=2;
		switch(a) {
		case 1:System.out.println("i am @ home");
		break;
		case 2:System.out.println("i am @ office");
		break;
		case 3:System.out.println("i am @ school");
		break;
		default:System.out.println("not anywhere");
		}

	}

}
