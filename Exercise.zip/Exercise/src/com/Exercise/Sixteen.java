package com.Exercise;

public class Sixteen {
	Sixteen(){
		System.out.println("creating a default constructor");
	}

	public static void main(String[] args) {
		Sixteen ob=new Sixteen();
	
	}

}
