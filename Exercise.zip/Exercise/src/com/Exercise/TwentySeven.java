package com.Exercise;
interface Deer{
	public void print_Deer();
}
interface Lion{
	public void print_Lion();
}
interface rabbit extends Deer,Lion{
	public void print_Rabbit();
}
class Child implements Rabbit{
	public void print_Deer() {
		System.out.println("run");
	}
	public void print_Lion() {
		System.out.println("toars");
	}
	public void print_Rabbit() {
		System.out.println("ROARS");
	}
}

public class TwentySeven {

	public static void main(String[] args) {
	Child x=new Child();
	x.print_Deer();
	x.print_Lion();
	x.print_Rabbit();

	}

}
