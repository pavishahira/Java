package com.Exercise;

public class Twenty {
	void sum(int a, int b) {
		System.out.println(a+b);
	}
	void sum(long a,long b) {
		System.out.println(a+b);
	}
  public static void main(String[] args) {
		Nineteen ob=new Nineteen();
		ob.sum(90, 70);
		ob.sum(67, 50);
	}

}
