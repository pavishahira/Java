package com.Exercise;
interface A{
	public void print_A();
}
interface B{
	public void print_B();
}
interface C extends A,B{
	public void print_C();
	void print_A();
	void print_B();	
}
class Children implements C{
	@Override
	public void print_A() {
System.out.println("run");	}
	@Override
	public void print_B() {
		System.out.println("roars");
	}
	@Override
	public void print_C() {
		System.out.println("ROARS");
	}
}

public abstract class TwentyEight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Children x=new Children();
		x.print_A();
		x.print_B();
		x.print_C();

	}

}
