package com.Exercise;

class ABC{
	public void print_ABC() {
		System.out.println("cooking");
	}
}
class QWE extends ABC{
	public void print_QWE() {
		System.out.println("emerging tech");
	}
}
class ASD extends QWE{
	public void print_ASD() {
		System.out.println("iot student");
	}
}
public class TwentySix {

	public static void main(String[] args) {
	ABC b=new ABC();
	b.print_ABC();
	ASD ob=new ASD();
	ob.print_ASD();
	QWE ob1=new QWE();
	ob1.print_QWE();

	}

}
