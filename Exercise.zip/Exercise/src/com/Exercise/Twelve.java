package com.Exercise;

public class Twelve {

	public static void main(String[] args) {
	int i=5;
	do {
		System.out.println("iot student"+i);
		i++;
	}
	while(i<=12);

	}

}
