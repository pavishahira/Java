package com.Exercise;
class City{
	String name;
	String population;
	void display() {
		System.out.println("city name"+name);
		System.out.println("population"+population);
	}
}

public class Fourteen {

	public static void main(String[] args) {
	City ob1=new City();
	City ob2=new City();
	ob1.name="chennai";
	ob1.population="3456678896654";
	System.out.println("Details of ob1 city");
	ob1.display();
	ob2.name="mumbai";
	ob2.population="3456677865654";
	System.out.println("Details of ob2 city");
	ob2.display();
	}

}
