package com.Exercise;
class ABC{
	public void print_ABC() {
		System.out.println("cooking");
	}
}
class XYZ extends ABC{
	public void print_XYZ() {
		System.out.println("emerging tech");
	}
}
class PQR extends XYZ{
	public void print_PQR() {
		System.out.println("iot student");
	}
}
public class TwentyFive {

	public static void main(String[] args) {
	PQR ob=new PQR();
	ob.print_XYZ();
	ob.print_ABC();
	ob.print_PQR();

	}

}
