package com.Exercise;

public class Thirteen {

	public static void main(String[] args) {
		for(int i=5;i<=10;i++) {
			System.out.println("iot student"+i);
		}

	}

}
