package com.Exercise;

public class TwentyOne {
	void sum(int a,double b) {
		System.out.println(a+b);
	}
	void sum(double a,long b) {
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		Nineteen ob=new Nineteen();
		ob.sum(678, 90.8);
		ob.sum(56675765785l, 67);

	}

}
