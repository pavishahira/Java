package com.Exercise;

public class Nineteen {
	void sum(int a,double d) {
		System.out.println(a+d);
	}
	void sum(double a,double d) {
		System.out.println(a+d);
	}

	public static void main(String[] args) {
	Nineteen ob=new Nineteen();
	ob.sum(78,78.5);
	ob.sum(56675765785l,77);

	}

}
